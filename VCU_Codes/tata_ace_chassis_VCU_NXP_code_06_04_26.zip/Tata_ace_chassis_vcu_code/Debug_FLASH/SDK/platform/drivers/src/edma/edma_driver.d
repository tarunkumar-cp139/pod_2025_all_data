SDK/platform/drivers/src/edma/edma_driver.o: \
 ../SDK/platform/drivers/src/edma/edma_driver.c \
 ../SDK/platform/drivers/src/edma/edma_irq.h \
 ../SDK/platform/drivers/src/edma/edma_hw_access.h \
 D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/edma_driver.h \
 D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/device_registers.h \
 D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/common/s32_core_cm4.h \
 D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/devassert.h \
 D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/status.h \
 D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock_manager.h \
 D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock.h \
 d:\pod_2025\vcu_codes\tata_ace_chassis_vcu_nxp_code_03_04_26\tata_ace_chassis_vcu_code\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/interrupt_manager.h

../SDK/platform/drivers/src/edma/edma_irq.h:

../SDK/platform/drivers/src/edma/edma_hw_access.h:

D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/edma_driver.h:

D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/device_registers.h:

D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/common/s32_core_cm4.h:

D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144.h:

D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/devassert.h:

D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/status.h:

D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock_manager.h:

D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock.h:

d:\pod_2025\vcu_codes\tata_ace_chassis_vcu_nxp_code_03_04_26\tata_ace_chassis_vcu_code\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

D:/Pod_2025/VCU_Codes/tata_ace_chassis_VCU_NXP_code_03_04_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/interrupt_manager.h:
