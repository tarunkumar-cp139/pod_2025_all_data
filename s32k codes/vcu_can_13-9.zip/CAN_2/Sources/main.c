/* ###################################################################
 **     Filename    : main.c
 **     Processor   : S32K1xx
 **     Abstract    :
 **         Main module.
 **         This module contains user's application code.
 **     Settings    :
 **     Contents    :
 **         No public methods
 **
 ** ###################################################################*/
/*!
 ** @file main.c
 ** @version 01.00
 ** @brief
 **         Main module.
 **         This module contains user's application code.
 */
/*!
 **  @addtogroup main_module main module documentation
 **  @{
 */
/* MODULE main */


/* Including necessary module. Cpu.h contains other modules needed for compiling.*/
#include "Cpu.h"
#include <string.h>
#include <stdio.h>
volatile int exit_code = 0;

/* User includes (#include below this line is not maintained by Processor Expert) */
flexcan_data_info_t can1_data_init_ext;
flexcan_data_info_t demo_data_init;
flexcan_msgbuff_t recvbuff_init;
flexcan_msgbuff_t rx_can1_init;



flexcan_data_info_t can2_data_init_ext;
flexcan_data_info_t can2_data_init;
flexcan_msgbuff_t rx_can2_init;
flexcan_msgbuff_t rx_can2_init_ext;

flexcan_data_info_t can0_data_init;
flexcan_msgbuff_t rx_can0_init;




//void master_can_callback(uint8_t instance, flexcan_event_type_t eventType,
//		uint32_t buffIdx, flexcan_state_t flexcanState);


void can0_callback(uint8_t instance, flexcan_event_type_t eventType,
		uint32_t buffIdx, flexcan_state_t flexcanState);

void can1_callback(uint8_t instance, flexcan_event_type_t eventType,
		uint32_t buffIdx, flexcan_state_t flexcanState);

void can2_callback(uint8_t instance, flexcan_event_type_t eventType,
		uint32_t buffIdx, flexcan_state_t flexcanState);
//flexcan_data_info_t demo_data_init;

char tx_buff[12];
char my_buff[12];
int len,k,count;
char myvalue[10];
uint8_t can_data[8]={0x01,0x02,0x03,0x04,0x05,0xB6,0x7A,0xAA};
uint8_t can_data_1[8]={0xA1,0x02,0x03,0x04,0x05,0xB6,0x7A,0xAA};
uint8_t can_data_2[8]={0xA2,0x02,0x03,0x04,0x05,0xB6,0x7A,0x2A};
uint8_t can_data_3[8]={0xA3,0x02,0x03,0x04,0x05,0xB6,0x7A,0x3A};
void Lp_Timer()

{

LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);

}

void timmer_config(){
	LPTMR_DRV_Init(INST_LPTMR1, &lpTmr1_config0,1);
		INT_SYS_InstallHandler(LPTMR0_IRQn,Lp_Timer,NULL);

	    INT_SYS_EnableIRQ(LPTMR0_IRQn);

		LPTMR_DRV_StartCounter(INST_LPTMR1);
		LPTMR_DRV_SetInterrupt(INST_LPTMR1,1);

}
void clock_config()
{
	CLOCK_DRV_Init(&clockMan1_InitConfig0);

}

void pin_config(){
	PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);
}


void can0_config(){
	FLEXCAN_DRV_Init(INST_CANCOM3, &canCom3_State, &canCom3_InitConfig0);
	can0_data_init.data_length= 8;
	can0_data_init.is_remote = false;
	can0_data_init.msg_id_type= FLEXCAN_MSG_ID_EXT;

	FLEXCAN_DRV_ConfigTxMb(INST_CANCOM3,4U,&can0_data_init, 0x180A0F4);
	FLEXCAN_DRV_SetRxMaskType(INST_CANCOM3,FLEXCAN_RX_MASK_GLOBAL);
	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM3,FLEXCAN_MSG_ID_EXT,0x0);
	FLEXCAN_DRV_ConfigRxMb(INST_CANCOM3,2U,&can0_data_init,0x0);
	FLEXCAN_DRV_InstallEventCallback(INST_CANCOM3,(flexcan_callback_t)&can0_callback, NULL);
	FLEXCAN_DRV_Receive(INST_CANCOM3,2U,&rx_can0_init);


}
void can2_config(){
	FLEXCAN_DRV_Init(INST_CANCOM2, &canCom2_State, &canCom2_InitConfig0);

	can2_data_init.data_length= 8;
	can2_data_init.is_remote = false;
	can2_data_init.msg_id_type= FLEXCAN_MSG_ID_STD;


	can2_data_init_ext=can2_data_init;
	can2_data_init_ext.msg_id_type = FLEXCAN_MSG_ID_EXT;
	FLEXCAN_DRV_ConfigTxMb(INST_CANCOM2,3U,&can2_data_init, 0x180e5F4);
	FLEXCAN_DRV_SetRxMaskType(INST_CANCOM2,FLEXCAN_RX_MASK_GLOBAL);
	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM2,FLEXCAN_MSG_ID_EXT,0x0);
	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM2,FLEXCAN_MSG_ID_STD,0x0);
	FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2,2U,&can2_data_init, 0x0);
	FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2,4U,&can2_data_init_ext, 0x0);

	FLEXCAN_DRV_InstallEventCallback(INST_CANCOM2,(flexcan_callback_t)&can2_callback, NULL);
	FLEXCAN_DRV_Receive(INST_CANCOM2,2U,&rx_can2_init);
	FLEXCAN_DRV_Receive(INST_CANCOM2,4U,&rx_can2_init_ext);
}
void can1_config()
{
	FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0);


		demo_data_init.data_length= 8;
		demo_data_init.is_remote = false;
		demo_data_init.msg_id_type= FLEXCAN_MSG_ID_STD;//FLEXCAN_MSG_ID_EXT;
	//	demo_data_init.msg_id_type= FLEXCAN_MSG_ID_EXT;
		can1_data_init_ext = demo_data_init;
		can1_data_init_ext.msg_id_type = FLEXCAN_MSG_ID_EXT;
		//FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1, 1U, &demo_data_init, msgid);
		//FLEXCAN_DRV_Send(INST_CANCOM1, 1U, &demo_data_init, msgid, data);
		//FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,1U,&demo_data_init, 0x180E5F4);
		// FLEXCAN_DRV_Receive(INST_CANCOM1, 0x18fe5f5,&recvbuff_init);


//FLEXCAN_DRV_Send(INST_CANCOM2,3U,&demo_data_init, 0x180E5E4,can_data);

        FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1,2U,&demo_data_init, 0x180E5F4);
		FLEXCAN_DRV_SetRxMaskType(INST_CANCOM1, FLEXCAN_RX_MASK_GLOBAL);
		FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM1,FLEXCAN_MSG_ID_STD , 0x0);//FLEXCAN_MSG_ID_EXT
		FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM1,FLEXCAN_MSG_ID_EXT , 0x0);

		FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,1U,&demo_data_init, 0x0);
		FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,3U,&can1_data_init_ext, 0x0);

		FLEXCAN_DRV_InstallEventCallback(INST_CANCOM1, (flexcan_callback_t)&can1_callback, NULL);
		FLEXCAN_DRV_Receive(INST_CANCOM1, 1U,&recvbuff_init);
		FLEXCAN_DRV_Receive(INST_CANCOM1, 3U,&rx_can1_init);
	///	FLEXCAN_DRV_Send(INST_CANCOM1,2U,&demo_data_init, 0x180E5F4,can_data);

}

void Uart_config(){
	LPUART_DRV_Init(INST_LPUART1, &lpuart1_State, &lpuart1_InitConfig0);
}

void can0_callback (uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t flexcanState)
{

	(void)flexcanState;

	(void) instance;

	switch(eventType){

	case FLEXCAN_EVENT_RX_COMPLETE:
	{

		FLEXCAN_DRV_Receive (INST_CANCOM3, 2U, &rx_can0_init);


	 if(rx_can0_init.msgId==0x180E3F1){
			                          count++;

	    sprintf(tx_buff,"CAN0");
		LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));
	    FLEXCAN_DRV_Send(INST_CANCOM3,3U,&can0_data_init, 0x180E4B1,can_data);
	   // rx_can0_init.msgId=0;


		}
	 if(rx_can0_init.msgId==0x180E3F2){
				                          count++;
		    FLEXCAN_DRV_Send(INST_CANCOM3,3U,&can0_data_init, 0x180E4B2,can_data);
		   // rx_can0_init.msgId=0;
										if(rx_can0_init.dataLen==8){


										}
	 }
	 if(rx_can0_init.msgId==0x180E3F4){
				                          count++;
		    FLEXCAN_DRV_Send(INST_CANCOM3,3U,&can0_data_init, 0x180E4B3,can_data);
		   // rx_can0_init.msgId=0;
										if(rx_can0_init.dataLen==8){


										}
	 }
	 if(rx_can0_init.msgId==0x180E3F5){
				                          count++;
		    FLEXCAN_DRV_Send(INST_CANCOM3,3U,&can0_data_init, 0x180E4B4,can_data);
		  //  rx_can0_init.msgId=0;
										if(rx_can0_init.dataLen==8){


										}
	 }
	 if(rx_can0_init.msgId==0x180E3F6){
				                          count++;
		    FLEXCAN_DRV_Send(INST_CANCOM3,3U,&can0_data_init, 0x180E4B5,can_data);
		  //  rx_can0_init.msgId=0;
										if(rx_can0_init.dataLen==8){


										}
	 }




		break;
	}
	}
}

void can1_callback (uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t flexcanState)
{

	(void)flexcanState;

	(void) instance;

	switch(eventType){

	case FLEXCAN_EVENT_RX_COMPLETE:
	{
		FLEXCAN_DRV_Receive (INST_CANCOM1, 1U, &recvbuff_init);
		FLEXCAN_DRV_Receive(INST_CANCOM1, 3U,&rx_can1_init);
		if(recvbuff_init.msgId==0x03)//0x180E1F4
		{
			recvbuff_init.msgId=0;

			count++;
//			if(recvbuff_init.dataLen==8)
//			{
//				//for (int i = 0; i < 8; i++) {

			//	 myvalue[i]=recvbuff_init.data[i];
//						 myvalue[1]=recvbuff_init.data[1];
//					     myvalue[2]=recvbuff_init.data[2];
//						 myvalue[3]=recvbuff_init.data[3];
//						 myvalue[4]=recvbuff_init.data[4];

			//	LPUART_DRV_SendData(INST_LPUART1,my_buff,strlen(my_buff));

							// sprintf(&my_buff, "%X ", myvalue[]);
						//}
				FLEXCAN_DRV_Send(INST_CANCOM1,8U,&demo_data_init, 0x50,can_data);
//		sprintf(tx_buff,"App");
//				LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));
//				}
//										    LPUART_DRV_SendDataBlocking(INST_LPUART1,tx_buff,strlen(tx_buff),100);


				///LPUART_DRV_SendDataBlocking(INST_LPUART1,recvbuff_init.data,strlen(recvbuff_init.data),1000);

//				if(recvbuff_init.data[4]==0)
//				{
//
//				}
		//	}


		}

		if(rx_can1_init.msgId==0x180E3F5)//0x180E1F4
				{
			FLEXCAN_DRV_Send(INST_CANCOM1,8U,&demo_data_init, 0x51,can_data);
				}


		break;
	}
	}

}

void can2_callback (uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t flexcanState)
{

	(void)flexcanState;

	(void) instance;

	switch(eventType){

	case FLEXCAN_EVENT_RX_COMPLETE:
	{

		FLEXCAN_DRV_Receive (INST_CANCOM2, 2U, &rx_can2_init);





	 if(rx_can2_init_ext.msgId==0x180E2F4){

          FLEXCAN_DRV_Send(INST_CANCOM2,4U,&can2_data_init_ext, 0x180E4F2,can_data);///mail box id should be different to all the can data that are in diff CAN's
		  rx_can2_init.msgId=0;
          count++;
//		  	  if(rx_can2_init.dataLen==8){
//
//
//							}


							}
	 if(rx_can2_init_ext.msgId==0x180128F1){

 FLEXCAN_DRV_Send(INST_CANCOM2,4U,&can2_data_init_ext, 0x180E422,can_data);///mail box id should be different to all the can data that are in diff CAN's
		//  rx_can2_init.msgId=0;
	 }
	 if(rx_can2_init_ext.msgId==0x180228F1){

	 FLEXCAN_DRV_Send(INST_CANCOM2,4U,&can2_data_init_ext, 0x180E422,can_data);///mail box id should be different to all the can data that are in diff CAN's
		//	  rx_can2_init.msgId=0;
		 }

	 if(rx_can2_init.msgId==0x447){
		 FLEXCAN_DRV_Send(INST_CANCOM2,8U,&can2_data_init, 0x21,can_data);///mail box id should be different to all the can data that are in diff CA
	 }
	 if(rx_can2_init.msgId==0x03){
			 FLEXCAN_DRV_Send(INST_CANCOM2,8U,&can2_data_init, 0x11,can_data);///mail box id should be different to all the can data that are in diff CA
		 }

		break;

	}
}
}

/*! 
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
 */
int main(void)
{
	/* Write your local variable definition here */

	/*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
#ifdef PEX_RTOS_INIT
	PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
#endif
	/*** End of Processor Expert internal initialization.                    ***/

	/* Write your code here */


	clock_config();
	pin_config();
	can0_config();
	can1_config();
	can2_config();
	Uart_config();
	PINS_DRV_SetPins(PTE,(1<<0));//pin 94
	PINS_DRV_SetPins(PTE,(1<<1));//pin 93
	PINS_DRV_SetPins(PTC,(1<<10));//PIN 52
	timmer_config();

	INT_SYS_InstallHandler(CAN1_ORed_IRQn,can1_callback,NULL);
	INT_SYS_InstallHandler(CAN0_ORed_IRQn,can0_callback,NULL);
	INT_SYS_InstallHandler(CAN2_ORed_IRQn,can0_callback,NULL);



INT_SYS_SetPriority(CAN0_ORed_IRQn,0);
INT_SYS_SetPriority(CAN1_ORed_IRQn,1);
INT_SYS_SetPriority(CAN2_ORed_IRQn,2);


INT_SYS_EnableIRQ(CAN0_ORed_IRQn);
INT_SYS_EnableIRQ(CAN1_ORed_IRQn);
INT_SYS_EnableIRQ(CAN2_ORed_IRQn);
	while(1)
	{
      //  FLEXCAN_DRV_Send(INST_CANCOM2,3U,&can2_data_init, 0x180E5F4,can_data);
	//FLEXCAN_DRV_Send(INST_CANCOM1,3U,&demo_data_init, 0x50,can_data_1);
	FLEXCAN_DRV_Send(INST_CANCOM2,7U,&can2_data_init_ext, 0x180E8F8,can_data_2);
//
	FLEXCAN_DRV_Send(INST_CANCOM3,9U,&can0_data_init, 0x180E9F9,can_data_3);

		sprintf(tx_buff,"App");
		LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));
		//LPUART_DRV_SendDataBlocking(INST_LPUART1,tx_buff,strlen(tx_buff),100);

		//for (int i = 0; i < 8; i++) {
//		 myvalue[0]=recvbuff_init.data[0];
//		 myvalue[1]=recvbuff_init.data[1];
//	     myvalue[2]=recvbuff_init.data[2];
//		 myvalue[3]=recvbuff_init.data[3];
//		 myvalue[4]=recvbuff_init.data[4];
//
//
//
//			 sprintf(&my_buff, "%X ", myvalue);
		//}

		//my_buff[len] = '\0'; // Null-terminate

  for (volatile uint32_t i = 0; i < 3000000; i++) __asm("NOP");
		//sprintf(my_buff[2],"%02x",recvbuff_init.data[4]);
	//	LPUART_DRV_SendDataBlocking(INST_LPUART1,my_buff,strlen(my_buff),1000);

	}

	/* For example: for(;;) { } */

	/*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
 ** @}
 */
/*
 ** ###################################################################
 **
 **     This file was created by Processor Expert 10.1 [05.21]
 **     for the NXP S32K series of microcontrollers.
 **
 ** ###################################################################
 */
