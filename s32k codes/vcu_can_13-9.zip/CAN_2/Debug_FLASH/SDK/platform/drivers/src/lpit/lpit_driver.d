SDK/platform/drivers/src/lpit/lpit_driver.o: \
 ../SDK/platform/drivers/src/lpit/lpit_driver.c \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/lpit_driver.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/status.h \
 ../SDK/platform/drivers/src/lpit/lpit_hw_access.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/devassert.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/clock.h \
 c:\users\tarun\workspaces32ds.arm.2.2\can_2\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/lpit_driver.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/status.h:

../SDK/platform/drivers/src/lpit/lpit_hw_access.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/devassert.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/clock.h:

c:\users\tarun\workspaces32ds.arm.2.2\can_2\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
