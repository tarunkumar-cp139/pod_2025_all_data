SDK/platform/drivers/src/flexcan/flexcan_hw_access.o: \
 ../SDK/platform/drivers/src/flexcan/flexcan_hw_access.c \
 ../SDK/platform/drivers/src/flexcan/flexcan_hw_access.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/flexcan_driver.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/devassert.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/rtos/osif/osif.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/status.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/edma_driver.h

../SDK/platform/drivers/src/flexcan/flexcan_hw_access.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/flexcan_driver.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/devassert.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/rtos/osif/osif.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/devices/status.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/CAN_2/SDK/platform/drivers/inc/edma_driver.h:
