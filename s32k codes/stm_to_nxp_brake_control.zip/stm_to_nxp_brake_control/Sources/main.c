/* ###################################################################
**     Filename    : main.c
**     Processor   : S32K1xx
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.00
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including necessary module. Cpu.h contains other modules needed for compiling.*/
#include "Cpu.h"

  volatile int exit_code = 0;

/* User includes (#include below this line is not maintained by Processor Expert) */

  flexcan_data_info_t can2_data_init_ext;
  flexcan_data_info_t can2_data_init;
  flexcan_msgbuff_t rx_can2_init;
  flexcan_msgbuff_t rx_can2_init_ext;

  flexcan_data_info_t can0_data_init;
  flexcan_msgbuff_t rx_can0_init;
uint16_t applied_press,byte4,byte5;

uint8_t data_brake[8];

  uint8_t TxData1[8],TxData[8],count=0,byte_5,byte_6,press_valid,count_inc=15,press_bar=30;
volatile bool brake_on=1;
   int sum;
   char tx_buff[128];
   volatile uint16_t twos16_via_func, twos_comp_u16 ,dec_u16,check_sum=0;
void timer_for_brake(void);
  void can0_callback(uint8_t instance, flexcan_event_type_t eventType,
  		uint32_t buffIdx, flexcan_state_t flexcanState);

//  void can1_callback(uint8_t instance, flexcan_event_type_t eventType,
//  		uint32_t buffIdx, flexcan_state_t flexcanState);

  void can2_callback(uint8_t instance, flexcan_event_type_t eventType,
  		uint32_t buffIdx, flexcan_state_t flexcanState);
  uint8_t can_data[8]={0x01,0x02,0x03,0x04,0x05,0xB6,0x7A,0xAA};


  void can0_config(){
  	//while(check){
  		//FLEXCAN_DRV_Init(INST_CANCOM1, &canCom3_State, &canCom3_InitConfig0);
  	FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0);
  	can0_data_init.data_length= 8;
  	can0_data_init.is_remote = false;
  	can0_data_init.msg_id_type= FLEXCAN_MSG_ID_STD;

  	FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1,4U,&can0_data_init, 0x0);
  	FLEXCAN_DRV_SetRxMaskType(INST_CANCOM1,FLEXCAN_RX_MASK_GLOBAL);
  	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM1,FLEXCAN_MSG_ID_STD,0x0);
  	FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,2U,&can0_data_init,0x0);
  	FLEXCAN_DRV_InstallEventCallback(INST_CANCOM1,(flexcan_callback_t)&can0_callback, NULL);
  	FLEXCAN_DRV_Receive(INST_CANCOM1,2U,&rx_can0_init);


  }
  void can2_config(){
  	FLEXCAN_DRV_Init(INST_CANCOM2, &canCom2_State, &canCom2_InitConfig0);

  	can2_data_init.data_length= 8;
  	can2_data_init.is_remote = false;
  	can2_data_init.msg_id_type= FLEXCAN_MSG_ID_STD;


  	can2_data_init_ext=can2_data_init;
  	can2_data_init_ext.msg_id_type = FLEXCAN_MSG_ID_EXT;
  	FLEXCAN_DRV_ConfigTxMb(INST_CANCOM2,3U,&can2_data_init, 0x0);
  	FLEXCAN_DRV_ConfigTxMb(INST_CANCOM2,5U,&can2_data_init_ext, 0x0);
  	FLEXCAN_DRV_SetRxMaskType(INST_CANCOM2,FLEXCAN_RX_MASK_GLOBAL);
  	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM2,FLEXCAN_MSG_ID_EXT,0x0);
  	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM2,FLEXCAN_MSG_ID_STD,0x0);
  	//	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM2,FLEXCAN_MSG_ID_STD,0x446);
  	//	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM2,FLEXCAN_MSG_ID_STD,0x02);
  	FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2,2U,&can2_data_init, 0x0);
  	//FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2,2U,&can2_data_init, 0x446);
  	FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2,4U,&can2_data_init_ext, 0x0);

  	FLEXCAN_DRV_InstallEventCallback(INST_CANCOM2,(flexcan_callback_t)&can2_callback, NULL);
  	FLEXCAN_DRV_Receive(INST_CANCOM2,2U,&rx_can2_init);
  	FLEXCAN_DRV_Receive(INST_CANCOM2,4U,&rx_can2_init_ext);
  }
  void can0_callback (uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t flexcanState)
  {

  	(void)flexcanState;

  	(void) instance;

  	switch(eventType){

  	case FLEXCAN_EVENT_RX_COMPLETE:
  	{

  		FLEXCAN_DRV_Receive (INST_CANCOM1, 2U, &rx_can0_init);


  		if(rx_can0_init.msgId==0x10A){
  			//count++;
byte4=rx_can0_init.data[4]<<8;
byte5=rx_can0_init.data[5];
  			applied_press=byte4|byte5;
  			applied_press=applied_press/10;

  			data_brake[0]=rx_can0_init.data[0];
  			data_brake[1]=rx_can0_init.data[1];
  			data_brake[2]=rx_can0_init.data[2];
  			data_brake[3]=rx_can0_init.data[3];
  			data_brake[4]=rx_can0_init.data[4];
  			data_brake[5]=rx_can0_init.data[5];
  			data_brake[6]=rx_can0_init.data[6];
  			data_brake[7]=rx_can0_init.data[7];


  			sprintf(tx_buff,"applied_press = %d\r\n",applied_press);
  			//LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));
LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));


  		}
//  		if(rx_can0_init.msgId==0x180E3F2){
//  		//	count++;
//  			FLEXCAN_DRV_Send(INST_CANCOM1,3U,&can0_data_init, 0x180E4B2,can_data);
//  			// rx_can0_init.msgId=0;
//  			if(rx_can0_init.dataLen==8){
//
//  			}
//  		}
  		break;
  	}
  	}
  }

  void can2_callback (uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t flexcanState)
  {

  	(void)flexcanState;

  	(void) instance;

  	switch(eventType){

  	case FLEXCAN_EVENT_RX_COMPLETE:
  	{
  		///assign mailbox execpt 2&4
  		FLEXCAN_DRV_Receive (INST_CANCOM2, 2U, &rx_can2_init);
  		//FLEXCAN_DRV_Receive(INST_CANCOM2,4U,&rx_can2_init_ext);




  		if(rx_can2_init.msgId==0x555){

  			if(rx_can2_init.data[0]==1){
  				brake_on=1;
  				press_bar=rx_can2_init.data[1];
//  				count_inc++;
//  				if(count_inc>=16){
//					count_inc=1;///byte 1
//				}
  				rx_can2_init.msgId=0;

  				//(INST_CANCOM3,3U,&can0_data_init, 0x180E4B2,can_data);
  			}else if(rx_can2_init.data[0]==0){
  				brake_on=0;
  				press_bar=rx_can2_init.data[1];//0bar
//  				count_inc++;
//  				if(count_inc>=16){
//					count_inc=1;///byte 1
//				}
  				rx_can2_init.msgId=0;
  			}


  			//FLEXCAN_DRV_Send(INST_CANCOM2,10U,&can2_data_init_ext, 0x180E4F2,can_data);///mail box id should be different to all the can data that are in diff CAN's
  			//  rx_can2_init.msgId=0;
  			//count++;
  			//		  	  if(rx_can2_init.dataLen==8){
  			//
  			//
  			//	0x1875FA1x						}


  		}
  	}
  	}
  }

  void timmer_config(){
  	LPTMR_DRV_Init(INST_LPTMR1, &lpTmr1_config0,1);
  	INT_SYS_InstallHandler(LPTMR0_IRQn,timer_for_brake,NULL);

  	INT_SYS_EnableIRQ(LPTMR0_IRQn);

  	LPTMR_DRV_StartCounter(INST_LPTMR1);
  	LPTMR_DRV_SetInterrupt(INST_LPTMR1,1);

  }

  void timer_for_brake()

  {
//  	if(brake_on==1){
//  	press_bar=rx_can2_init.data[1];
//    				count=16;///byte 1
//    						press_valid=16;//byte 2
//    						byte_5=(press_bar*2)>>4;
//    						byte_6=((press_bar*2)&0x0f)<<4;
//
//    					  dec_u16= (count+press_valid+byte_5+byte_6);                 // 240
//    					  volatile uint16_t ones_comp_u16    = (uint16_t)(~dec_u16);      // one's complement,CONVERT 1's to 0's and vice versa
//    					 twos_comp_u16    = (uint16_t)(ones_comp_u16 + 1u); // two's complement= one's complement+1 // Expected: ones_comp_u16 = 0xFF0F, twos_comp_u16 = 0xFF10
//
//    				     check_sum=twos_comp_u16&0xff;
//
//    						TxData1[0]=check_sum;
//    						TxData1[1]=count;//count
//    						TxData1[2]=0x0;
//    						TxData1[3]=press_valid;
//    						TxData1[4]=0x00;
//    						TxData1[5]=byte_5;
//    						TxData1[6]=byte_6;
//    						TxData1[7]=0x0;
//    						FLEXCAN_DRV_Send(INST_CANCOM1,8U,&can0_data_init, 0x2AC,TxData1);
//
//  }
	  FLEXCAN_DRV_Send(INST_CANCOM2,5U,&can2_data_init_ext, 0x1874530,data_brake);
  	LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);

  }
/*! 
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
*/
int main(void)
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
    CLOCK_DRV_Init(&clockMan1_InitConfig0);
    PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);
    LPUART_DRV_Init(INST_LPUART1, &lpuart1_State, &lpuart1_InitConfig0);
    can0_config();
    //	can1_config();
    	can2_config();
    	timmer_config();
    //	Uart_config();
    	PINS_DRV_SetPins(PTE,(1<<0));//pin 94
    	PINS_DRV_SetPins(PTE,(1<<1));//pin 93
    while(1){

    	if(brake_on==1){
    		//press_bar=30;//rx_can2_init.data[1];
    							count=count_inc<<4;///byte 1
        						press_valid=16;//byte 2
        						byte_5=(press_bar*2)>>4;
        						byte_6=((press_bar*2)&0x0f)<<4;

        					  dec_u16= (count+press_valid+byte_5+byte_6);                 // 240
        					  volatile uint16_t ones_comp_u16    = (uint16_t)(~dec_u16);      // one's complement,CONVERT 1's to 0's and vice versa
        					 twos_comp_u16    = (uint16_t)(ones_comp_u16 + 1u); // two's complement= one's complement+1 // Expected: ones_comp_u16 = 0xFF0F, twos_comp_u16 = 0xFF10

        				     check_sum=twos_comp_u16&0xff;

        						TxData1[0]=check_sum;
        						TxData1[1]=count;//count
        						TxData1[2]=0x0;
        						TxData1[3]=press_valid;
        						TxData1[4]=0x00;
        						TxData1[5]=byte_5;
        						TxData1[6]=byte_6;
        						TxData1[7]=0x0;
        						FLEXCAN_DRV_Send(INST_CANCOM1,8U,&can0_data_init, 0x2AC,TxData1);
        						count_inc++;
        						  				if(count_inc>=16){
        											count_inc=1;///byte 1
        										}

        						//  OSIF_TimeDelay(5);
//        						if(count>16){
//        							count_inc=0;///byte 1
//        						}
//        						else if (count>=16){
//        							count=0;
//        						}


//
//
//        														TxData1[0]=check_sum_speed;
//        						        						TxData1[1]=count;//count
//        						        						TxData1[2]=0x0;
//        						        						TxData1[3]=press_valid;
//        						        						TxData1[4]=0x00;
//        						        						TxData1[5]=byte_5;
//        						        						TxData1[6]=byte_6;
//        						        						TxData1[7]=0x0;
//

      }
    	else if(brake_on==0){
    		//press_bar=0;//rx_can2_init.data[1];
		        				count=count_inc<<4;///byte 1
		        						press_valid=16;//byte 2
		        						byte_5=(press_bar*2)>>4;
		        						byte_6=((press_bar*2)&0x0f)<<4;

		        					  dec_u16= (count+press_valid+byte_5+byte_6);                 // 240
		        					  volatile uint16_t ones_comp_u16    = (uint16_t)(~dec_u16);      // one's complement,CONVERT 1's to 0's and vice versa
		        					 twos_comp_u16    = (uint16_t)(ones_comp_u16 + 1u); // two's complement= one's complement+1 // Expected: ones_comp_u16 = 0xFF0F, twos_comp_u16 = 0xFF10

		        				     check_sum=twos_comp_u16&0xff;

		        						TxData1[0]=check_sum;
		        						TxData1[1]=count;//count
		        						TxData1[2]=0x0;
		        						TxData1[3]=press_valid;
		        						TxData1[4]=0x00;
		        						TxData1[5]=byte_5;
		        						TxData1[6]=byte_6;
		        						TxData1[7]=0x0;
		        						FLEXCAN_DRV_Send(INST_CANCOM1,8U,&can0_data_init, 0x2AC,TxData1);
		        						count_inc++;
										if(count_inc>=16){
											count_inc=1;///byte 1
										}
		        						 // OSIF_TimeDelay(5);
//		        						if(count_inc<16){
//		        							count_inc=count_inc+1;///byte 1
//										}else if (count_inc>=16){
//											count_inc=0;
//										}
    	}

    OSIF_TimeDelay(10);
  //  FLEXCAN_DRV_Send(INST_CANCOM1,8U,&can0_data_init, 0x2AC,TxData1);
    }

  /* For example: for(;;) { } */

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
