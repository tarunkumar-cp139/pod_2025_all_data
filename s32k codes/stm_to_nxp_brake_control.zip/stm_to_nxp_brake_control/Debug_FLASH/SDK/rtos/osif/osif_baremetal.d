SDK/rtos/osif/osif_baremetal.o: ../SDK/rtos/osif/osif_baremetal.c \
 ../SDK/rtos/osif/osif.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/status.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/devassert.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/devassert.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/clock.h \
 c:\users\tarun\workspaces32ds.arm.2.2\stm_to_nxp_brake_control\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

../SDK/rtos/osif/osif.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/status.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/devassert.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/devassert.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/clock.h:

c:\users\tarun\workspaces32ds.arm.2.2\stm_to_nxp_brake_control\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
