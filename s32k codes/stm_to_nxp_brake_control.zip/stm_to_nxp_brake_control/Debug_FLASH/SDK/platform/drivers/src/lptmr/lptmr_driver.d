SDK/platform/drivers/src/lptmr/lptmr_driver.o: \
 ../SDK/platform/drivers/src/lptmr/lptmr_driver.c \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/lptmr_driver.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/status.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/devassert.h \
 ../SDK/platform/drivers/src/lptmr/lptmr_hw_access.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/clock.h \
 c:\users\tarun\workspaces32ds.arm.2.2\stm_to_nxp_brake_control\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/lptmr_driver.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/status.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/devassert.h:

../SDK/platform/drivers/src/lptmr/lptmr_hw_access.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/clock.h:

c:\users\tarun\workspaces32ds.arm.2.2\stm_to_nxp_brake_control\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
