Generated_Code/pin_mux.o: ../Generated_Code/pin_mux.c \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/devassert.h \
 ../Generated_Code/pin_mux.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/pins_driver.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/status.h

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/devassert.h:

../Generated_Code/pin_mux.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/drivers/inc/pins_driver.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/stm_to_nxp_brake_control/SDK/platform/devices/status.h:
