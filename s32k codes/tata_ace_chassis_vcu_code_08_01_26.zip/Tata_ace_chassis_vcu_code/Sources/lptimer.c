/*
 * lptimer.c
 *
 *  Created on: 04-Dec-2025
 *      Author: Tarun
 */
#include "lptimer.h"
void timer_for_10ms(){

  sending_data_to_brake();


  all_ecu_fault_check();


  if(send_data_to_pdu_flag==1){
		pdu.count_to_send_data++;
	if(pdu.count_to_send_data>=10){
		sending_data_to_pdu();
		pdu.count_to_send_data=0;
	}
  }

  obc.count_to_send_data++;
  if( obc.count_to_send_data>=10){
	sending_data_to_obc();
	 obc.count_to_send_data=0;

  }
  if(pid_enable==1){
	pid_time_count++;
	  if(pid_time_count>=10){
		  if(Motor_rpm)
		  {
 	        Input=mcu.rpm;
 	 		PID_Compute(&TPID);
 	 	//	Output=680;
 	 		MCP4921_SetOutput((uint16_t)Output);
 	 		Motor_rpm=false;
		  }
		//  snprintf(tx_buff, sizeof(tx_buff), "Output: %d,motor_rpm :%d , speed : %d ,kp : %d ,ki : %d ,kd : %d ,setpoint :  %d\r\n", (uint16_t)Output,(uint16_t)mcu.rpm,(uint16_t)(mcu.speed*10),(uint16_t)(consKp*10),(uint16_t)(consKi*10),(uint16_t)(consKd*10),(uint16_t)Setpoint);

		  snprintf(tx_buff, sizeof(tx_buff), "Output: %.2f,motor_rpm :%.2f, speed : %.2f ,kp : %.3f ,ki : %.3f ,kd : %.3f ,setpoint :  %.2f\r\n",Output,mcu.rpm,(mcu.speed),(consKp),(consKi),(consKd),Setpoint);
		  		LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));
 	 		//press_bar=0;
 	 		pid_time_count=0;
	     }
 	  }
    else if(pid_enable==0){
		TPID.OutputSum=0;
		Output=0;
		MCP4921_SetOutput((uint16_t)Output);
    }





fault.count_to_send_data++;
if(fault.count_to_send_data>=5){
	if(fault_can_mesg());
	fault.count_to_send_data=0;
}


 LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);
}
void timer_config(){
  	LPTMR_DRV_Init(INST_LPTMR1, &lpTmr1_config0,1);
  	INT_SYS_InstallHandler(LPTMR0_IRQn,timer_for_10ms,NULL);

  	INT_SYS_EnableIRQ(LPTMR0_IRQn);

  	LPTMR_DRV_StartCounter(INST_LPTMR1);
  	LPTMR_DRV_SetInterrupt(INST_LPTMR1,1);


  }
