/*
 * apm_std.c
 *
 *  Created on: 06-Jan-2026
 *      Author: Tarun
 */


#include "apm_std.h"

void apm_std_check(int condition_check){


}
bool stop_check(void){
	if(door_status==1  && motor_check_on==0 && applied_press ==30 && mcu.rpm ==0)
		return 1;
	else
		return 0;
}

bool door_status(void){

}

bool over_speed_check(void){
	if(mcu.rpm>=300){
			current_state =FAULT;//STOP
			return 1;
		}
	else
		return 0;
}

void all_ecu_fault_check(void){

	//motor CAN Data check
	if(motor_state && motor_check_on){
		  mcu.count_fault_check++;
		  if(mcu.count_fault_check>=250){//every 2.5sec
				if(mcu.data_check==0){

					mcu.can_fault=1;
					current_state =FAULT;
					motor_state=0;
					send_data_to_pdu_flag=1;
					pid_enable=0;
					press_bar=30;
					state_status=0;
					throttle_relay_off;
					TPID.OutputSum=0;
					Output=0;
					MCP4921_SetOutput((uint16_t)Output);

				}
				mcu.data_check=0;
				mcu.count_fault_check=0;

		  }
	}

	//PDU CAN Data check
	pdu.count_fault_check++;
	if((current_state==1) && (send_data_to_pdu_flag==1)){
		start_pdu_check=1;
	}
	if(start_pdu_check==1){
		if(pdu.count_fault_check>300){//every 3sec
			if(pdu.data_check==0){
				pdu.can_fault=1;
				current_state =FAULT;
			}
			pdu.data_check=0;
		    pdu.count_fault_check=0;
		}
	}

	////Brake CAN Data check
	/*
	brake.count_fault_check++;
	if((current_state>=1 && pdu.on==1)) {
		if(brake.count_fault_check>=25){//every 250ms
				brake.can_fault=1;
				current_state =FAULT;

			}
		brake.data_check=0;
		brake.count_fault_check=0;
		}
   */
}


