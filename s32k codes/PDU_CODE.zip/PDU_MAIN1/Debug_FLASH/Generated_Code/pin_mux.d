Generated_Code/pin_mux.o: ../Generated_Code/pin_mux.c \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/device_registers.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h \
 ../Generated_Code/pin_mux.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/pins_driver.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/status.h

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/device_registers.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h:

../Generated_Code/pin_mux.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/pins_driver.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/status.h:
