SDK/platform/drivers/src/lptmr/lptmr_hw_access.o: \
 ../SDK/platform/drivers/src/lptmr/lptmr_hw_access.c \
 ../SDK/platform/drivers/src/lptmr/lptmr_hw_access.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/device_registers.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/lptmr_driver.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/status.h

../SDK/platform/drivers/src/lptmr/lptmr_hw_access.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/device_registers.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/lptmr_driver.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/status.h:
