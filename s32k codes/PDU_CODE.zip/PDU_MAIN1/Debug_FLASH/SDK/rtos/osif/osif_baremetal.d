SDK/rtos/osif/osif_baremetal.o: ../SDK/rtos/osif/osif_baremetal.c \
 ../SDK/rtos/osif/osif.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/status.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/device_registers.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/clock.h \
 c:\users\alfia\downloads\pdu_main1\pdu_main1\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

../SDK/rtos/osif/osif.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/status.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/device_registers.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Alfia/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/clock.h:

c:\users\alfia\downloads\pdu_main1\pdu_main1\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
