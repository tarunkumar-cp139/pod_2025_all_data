SDK/platform/drivers/src/lpuart/lpuart_irq.o: \
 ../SDK/platform/drivers/src/lpuart/lpuart_irq.c \
 ../SDK/platform/drivers/src/lpuart/lpuart_irq.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/device_registers.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/interrupt_manager.h

../SDK/platform/drivers/src/lpuart/lpuart_irq.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/device_registers.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/interrupt_manager.h:
