SDK/platform/drivers/src/pdb/pdb_driver.o: \
 ../SDK/platform/drivers/src/pdb/pdb_driver.c \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/pdb_driver.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/clock.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/device_registers.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/status.h \
 c:\users\tarun\downloads\pdu_main1\pdu_main1\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 ../SDK/platform/drivers/src/pdb/pdb_hw_access.h \
 C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/interrupt_manager.h

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/pdb_driver.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/clock.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/device_registers.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/devassert.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/devices/status.h:

c:\users\tarun\downloads\pdu_main1\pdu_main1\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

../SDK/platform/drivers/src/pdb/pdb_hw_access.h:

C:/Users/Tarun/Downloads/PDU_MAIN1/PDU_MAIN1/SDK/platform/drivers/inc/interrupt_manager.h:
