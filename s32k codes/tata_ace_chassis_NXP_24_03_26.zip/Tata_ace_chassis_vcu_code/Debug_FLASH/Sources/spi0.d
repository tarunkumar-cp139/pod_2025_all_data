Sources/spi0.o: ../Sources/spi0.c ../Sources/spi0.h ../Sources/main.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Sources/pin_config.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Sources/main.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/Cpu.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/device_registers.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/common/s32_core_cm4.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/devassert.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/status.h \
 d:\pod_2025\s32k\ codes\tata_ace_chassis_10_03_26\tata_ace_chassis_vcu_code\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/rtos/osif/osif.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/edma_driver.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/flexcan_driver.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/edma_driver.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lpuart_driver.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/callbacks.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lptmr_driver.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lpspi_master_driver.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lpspi_shared_function.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock_manager.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lpspi_slave_driver.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lpspi_shared_function.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/wdog_driver.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/startup/system_S32K144.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/pin_mux.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/pins_driver.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/clockMan1.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/Cpu.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/dmaController1.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/canCom1.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/canCom2.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/canCom3.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/lpuart1.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/lpTmr1.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/lpspiCom1.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/watchdog1.h \
 ../Sources/syst_clk.h ../Sources/can0.h ../Sources/can1.h \
 ../Sources/can2.h ../Sources/system_states.h ../Sources/uart0.h \
 ../Sources/lptimer.h ../Sources/pid.h ../Sources/apm_std.h \
 D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Sources/main.h

../Sources/spi0.h:

../Sources/main.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Sources/pin_config.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Sources/main.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/Cpu.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/device_registers.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/common/s32_core_cm4.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/devassert.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/interrupt_manager.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/status.h:

d:\pod_2025\s32k\ codes\tata_ace_chassis_10_03_26\tata_ace_chassis_vcu_code\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/rtos/osif/osif.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/edma_driver.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/flexcan_driver.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/edma_driver.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lpuart_driver.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/interrupt_manager.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/callbacks.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lptmr_driver.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lpspi_master_driver.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lpspi_shared_function.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock_manager.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lpspi_slave_driver.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/lpspi_shared_function.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/wdog_driver.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/startup/system_S32K144.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/pin_mux.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/pins_driver.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/clockMan1.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/Cpu.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/dmaController1.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/canCom1.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/canCom2.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/canCom3.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/lpuart1.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/lpTmr1.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/lpspiCom1.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Generated_Code/watchdog1.h:

../Sources/syst_clk.h:

../Sources/can0.h:

../Sources/can1.h:

../Sources/can2.h:

../Sources/system_states.h:

../Sources/uart0.h:

../Sources/lptimer.h:

../Sources/pid.h:

../Sources/apm_std.h:

D:/Pod_2025/s32k\ codes/Tata_ace_chassis_10_03_26/Tata_ace_chassis_vcu_code/Sources/main.h:
