/* ###################################################################
**     Filename    : main.c
**     Processor   : S32K1xx
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.00
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including necessary module. Cpu.h contains other modules needed for compiling.*/
#include "Cpu.h"
#include "pid.h"
#include "stdio.h"
#include <string.h>
  volatile int exit_code = 0;

/* User includes (#include below this line is not maintained by Processor Expert) */
  uint8_t spi_data=8;
  PID_TypeDef TPID;
int i=0;
status_t var;
uint8_t can_data_1[8]={0xA1,0x02,0x03,0x04,0x05,0xB6,0x7A,0x1A};
  double consKp=1.0, consKi=0.9, consKd=0.05;  ///NEW TRAY TD01
  //double consKp=1.7, consKi=1.4, consKd=0.3;  ///NEW TRAY TD01
  double Input=0, Output=0;
  double Setpoint=100,motor_rpm;//90

  char tx_buff[128];
  uint16_t out_dac=0;
  uint8_t TxData1[8],TxData[8],count,byte_5,byte_6,press_valid;

  int press_bar,sum;
  volatile uint16_t twos16_via_func, twos_comp_u16 ,dec_u16,check_sum=0;
    flexcan_data_info_t can1_data_init_ext;
	flexcan_data_info_t can1_data_init;
	flexcan_msgbuff_t rx_can1_init;
	flexcan_msgbuff_t rx_can1_init_ext;
	void can1_callback (uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t flexcanState);
	void can_config(void);
	//status_t MCP4921_SetOutput(uint16_t dac_value);
	void MCP4921_SetOutput(uint16_t dac_value);
  void can_config(void){
	FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0);

	can1_data_init.data_length= 8;
	can1_data_init.is_remote = false;
	can1_data_init.msg_id_type= FLEXCAN_MSG_ID_STD;//FLEXCAN_MSG_ID_EXT;
//	can1_data_init.msg_id_type= FLEXCAN_MSG_ID_EXT;
	can1_data_init_ext = can1_data_init;
	can1_data_init_ext.msg_id_type = FLEXCAN_MSG_ID_EXT;
	//FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1, 1U, &can1_data_init, msgid);
	//FLEXCAN_DRV_Send(INST_CANCOM1, 1U, &can1_data_init, msgid, data);
	//FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,1U,&can1_data_init, 0x180E5F4);
	// FLEXCAN_DRV_Receive(INST_CANCOM1, 0x18fe5f5,&rx_can1_init);


//FLEXCAN_DRV_Send(INST_CANCOM2,3U,&can1_data_init, 0x180E5E4,can_data);

    FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1,2U,&can1_data_init, 0x180E5F4);
	FLEXCAN_DRV_SetRxMaskType(INST_CANCOM1, FLEXCAN_RX_MASK_GLOBAL);
	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM1,FLEXCAN_MSG_ID_STD , 0x0);//FLEXCAN_MSG_ID_EXT
	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM1,FLEXCAN_MSG_ID_EXT , 0x0);

	FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,1U,&can1_data_init, 0x0);
	FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,3U,&can1_data_init_ext, 0x0);

	FLEXCAN_DRV_InstallEventCallback(INST_CANCOM1, (flexcan_callback_t)&can1_callback, NULL);
	FLEXCAN_DRV_Receive(INST_CANCOM1, 1U,&rx_can1_init);
	FLEXCAN_DRV_Receive(INST_CANCOM1, 3U,&rx_can1_init_ext);
///	FLEXCAN_DRV_Send(INST_CANCOM1,2U,&can1_data_init, 0x180E5F4,can_data);


}


void can1_callback (uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t flexcanState)
{

	(void)flexcanState;

	(void) instance;

	switch(eventType){

	case FLEXCAN_EVENT_RX_COMPLETE:
	{
		FLEXCAN_DRV_Receive (INST_CANCOM1, 1U, &rx_can1_init);
		FLEXCAN_DRV_Receive(INST_CANCOM1, 3U,&rx_can1_init_ext);


if(rx_can1_init_ext.msgId==0x180128F1)//0x180E1F4
				{
			FLEXCAN_DRV_Send(INST_CANCOM1,9U,&can1_data_init, 0x511,rx_can1_init_ext.data);



//							motor_can[0]=rxData[0];
//							motor_can[1]=rxData[1];
//							motor_can[2]=rxData[2];
//							motor_can[3]=rxData[3];
//							motor_can[4]=rxData[4];
//							motor_can[5]=rxData[5];
//							motor_can[6]=rxData[6];
//							motor_can[7]=rxData[7];

		motor_rpm=rx_can1_init_ext.data[6]+rx_can1_init_ext.data[7]*256;
		//motor_rpm=motor_rpm/8;
		//canspeed=(2*3.14*0.825*motor_rpm)/60;
//							canspeed=(3.14*0.630*motor_rpm)/(60*8);//(3.14*wheel dia *moter rpm / gear ratio(8))/60(sec))
//							motor_voltage=motor_can[0]+motor_can[1]*256;
//							motor_voltage=motor_voltage/10;
//							motor_current=motor_can[2]+motor_can[3]*256;
//							motor_current=motor_current/10;
//							motor_phase_current=motor_can[4]+motor_can[5]*256;
//							motor_phase_current=motor_phase_current/10;
//							checking_for_motor_CAN_data=1;

//						}
			i=1;

				}
if(rx_can1_init.msgId==0x411)//
				{
	rx_can1_init.msgId=0;
			FLEXCAN_DRV_Send(INST_CANCOM1,10U,&can1_data_init, 0x611,rx_can1_init.data);
			press_bar=rx_can1_init.data[0];
			i=2;


	}
if(rx_can1_init.msgId==0x412)//
				{
	rx_can1_init.msgId=0;
			FLEXCAN_DRV_Send(INST_CANCOM1,10U,&can1_data_init, 0x612,rx_can1_init.data);
		//	press_bar=rx_can1_init.data[0];
			i=3;


	}

	}

}

}

void MCP4921_SetOutput(uint16_t dac_value)
{
    /* Limit to 12 bits */
    dac_value &= 0x0FFFU;

    /* Build control word:
       bit14 BUF=1 (buffered Vref),
       bit13 GA=1 (1x gain),
       bit12 SHDN=1 (active),
       bits[11:0] = value
    */
    dac_value &= 0x0FFFU;
    uint16_t word = (1U << 14) | (1U << 13) | (1U << 12) | dac_value;

    /* MSB first */
    uint8_t tx[2];
    tx[0] = (uint8_t)(word >> 8);
    tx[1] = (uint8_t)(word & 0xFF);
    LPSPI_DRV_SetPcs(LPSPICOM1,LPSPI_PCS0,LPSPI_ACTIVE_LOW);
    /* Blocking transfer of exactly 2 bytes.
       Make sure your LPSPI component is Mode0, MSB-first, PCS0 active-low,
       and PCS continuous = true so CS stays low across both bytes. */
  // LPSPI_DRV_MasterTransferBlocking(LPSPICOM1, tx, NULL, 2U, 10U);

    LPSPI_DRV_MasterTransfer(LPSPICOM1,tx,NULL,2);
   // LPSPI_DRV_SetPcs(LPSPICOM1,LPSPI_PCS0,LPSPI_ACTIVE_HIGH);
}

void PID_cont(void){
	if(i==1){
		   Input=motor_rpm;
			PID_Compute(&TPID);
			//	Output=0;

		MCP4921_SetOutput((uint16_t)Output);
		press_bar=0;
		LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);

     }
	else if(i==2){
			Output=0;
			MCP4921_SetOutput(Output);

		count=16;///byte 1
		press_valid=16;//byte 2
		byte_5=(press_bar*2)>>4;
		byte_6=((press_bar*2)&0x0f)<<4;

	  dec_u16= (count+press_valid+byte_5+byte_6);                 // 240
	  volatile uint16_t ones_comp_u16    = (uint16_t)(~dec_u16);      // one's complement,CONVERT 1's to 0's and vice versa
	 twos_comp_u16    = (uint16_t)(ones_comp_u16 + 1u); // two's complement= one's complement+1 // Expected: ones_comp_u16 = 0xFF0F, twos_comp_u16 = 0xFF10

     check_sum=twos_comp_u16&0xff;

		TxData1[0]=check_sum;
		TxData1[1]=count;//count
		TxData1[2]=0x0;
		TxData1[3]=press_valid;
		TxData1[4]=0x00;
		TxData1[5]=byte_5;
		TxData1[6]=byte_6;
		TxData1[7]=0x0;
		FLEXCAN_DRV_Send(INST_CANCOM1,8U,&can1_data_init, 0x2AC,TxData1);

	LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);
	}
	else{
		LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);
	}

}

void timer_intrrupt(void){


LPTMR_DRV_Init(INST_LPTMR1, &lpTmr1_config0,1);
INT_SYS_InstallHandler(LPTMR0_IRQn,PID_cont,NULL);
INT_SYS_EnableIRQ(LPTMR0_IRQn);

LPTMR_DRV_StartCounter(INST_LPTMR1);

LPTMR_DRV_SetInterrupt(INST_LPTMR1,1);
}
/*! 
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
 *
 *
 *
*/
int main(void)
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
  /* For example: for(;;) { } */
CLOCK_DRV_Init(&clockMan1_InitConfig0);
PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);
LPSPI_DRV_MasterInit(LPSPICOM1,&lpspiCom1State,&lpspiCom1_MasterConfig0);
LPUART_DRV_Init(INST_LPUART1, &lpuart1_State, &lpuart1_InitConfig0);
can_config();
timer_intrrupt();
    PID(&TPID, &Input, &Output, &Setpoint, consKp, consKi, consKd, _PID_P_ON_E, _PID_CD_DIRECT);
  	PID_SetMode(&TPID, _PID_MODE_AUTOMATIC);
  	PID_SetSampleTime(&TPID,50);
  	PID_SetOutputLimits(&TPID,500,1000);//1700
  	LPSPI_DRV_SetPcs(LPSPICOM1,LPSPI_PCS0,LPSPI_ACTIVE_LOW);

  	Output=0;
  	MCP4921_SetOutput(Output);

  	INT_SYS_SetPriority(LPSPI0_IRQn,0);
  	INT_SYS_SetPriority(LPTMR0_IRQn,1);
  	INT_SYS_SetPriority(CAN1_ORed_IRQn,2);

  	//LPUART_DRV_ReceiveData(INST_LPUART1,);
//  	INT_SYS_EnableIRQ(LPSPI0_IRQn);
//  	INT_SYS_EnableIRQ(LPTMR0_IRQn);
//  	INT_SYS_EnableIRQ(CAN1_ORed_IRQn);

//  	var=check;
//  	PINS_DRV_SetPinIntSel(PTC,1<<10,PORT_INT_RISING_EDGE);
//  	INT_SYS_InstallHandler(PORTA_IRQn,gpio_inpt,NULL);
//  	INT_SYS_EnableIRQ(PORTA_IRQn);



  	while(1){

  		FLEXCAN_DRV_Send(INST_CANCOM1,11U,&can1_data_init_ext, 0x180E421,can_data_1);///mail box id should be different to all the can data that are in diff CAN's


  		 snprintf(tx_buff, sizeof(tx_buff), "Output: %d, motor_rpm: %d ,press_bar :%d  i= %d\r\n", (uint16_t)Output, (uint16_t)motor_rpm,press_bar,i);

  		  LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));

OSIF_TimeDelay(100);

  	}
/*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
