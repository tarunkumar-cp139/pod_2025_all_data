SDK/platform/drivers/src/lpspi/lpspi_master_driver.o: \
 ../SDK/platform/drivers/src/lpspi/lpspi_master_driver.c \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/lpspi_master_driver.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/lpspi_shared_function.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/edma_driver.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/common/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/S32K144/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/S32K144/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/devassert.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/status.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/clock.h \
 c:\users\tarun\workspaces32ds.arm.2.2\throttle_cont\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/rtos/osif/osif.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/callbacks.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/interrupt_manager.h \
 ../SDK/platform/drivers/src/lpspi/lpspi_hw_access.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/lpspi_shared_function.h

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/lpspi_master_driver.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/lpspi_shared_function.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/edma_driver.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/common/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/S32K144/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/S32K144/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/devassert.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/status.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/clock.h:

c:\users\tarun\workspaces32ds.arm.2.2\throttle_cont\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/rtos/osif/osif.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/callbacks.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/interrupt_manager.h:

../SDK/platform/drivers/src/lpspi/lpspi_hw_access.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/drivers/inc/lpspi_shared_function.h:
