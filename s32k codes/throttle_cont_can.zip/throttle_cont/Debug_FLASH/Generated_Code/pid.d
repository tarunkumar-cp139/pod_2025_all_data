Generated_Code/pid.o: ../Generated_Code/pid.c ../Generated_Code/pid.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/rtos/osif/osif.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/status.h

../Generated_Code/pid.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/rtos/osif/osif.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/throttle_cont/SDK/platform/devices/status.h:
