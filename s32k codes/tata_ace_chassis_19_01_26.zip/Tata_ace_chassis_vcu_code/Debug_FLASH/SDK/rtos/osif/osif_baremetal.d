SDK/rtos/osif/osif_baremetal.o: ../SDK/rtos/osif/osif_baremetal.c \
 ../SDK/rtos/osif/osif.h \
 D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/status.h \
 D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/device_registers.h \
 D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/common/s32_core_cm4.h \
 D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144.h \
 D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144_features.h \
 D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/devassert.h \
 D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/devassert.h \
 D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/interrupt_manager.h \
 D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock_manager.h \
 D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock.h \
 d:\pod_2025\s32k\ codes\tata_ace_chassis_30_12\tata_ace_chassis_vcu_code\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

../SDK/rtos/osif/osif.h:

D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/status.h:

D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/device_registers.h:

D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/common/s32_core_cm4.h:

D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144.h:

D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/S32K144/include/S32K144_features.h:

D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/devassert.h:

D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/devices/devassert.h:

D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/interrupt_manager.h:

D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock_manager.h:

D:/Pod_2025/s32k\ codes/tata_ace_chassis_30_12/Tata_ace_chassis_vcu_code/SDK/platform/drivers/inc/clock.h:

d:\pod_2025\s32k\ codes\tata_ace_chassis_30_12\tata_ace_chassis_vcu_code\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
