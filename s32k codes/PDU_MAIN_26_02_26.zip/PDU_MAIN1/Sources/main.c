/* ###################################################################
**     Filename    : main.c
**     Processor   : S32K1xx
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.00
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including necessary module. Cpu.h contains other modules needed for compiling.*/
#include "Cpu.h"
#include "math.h"

  volatile int exit_code = 0;

#define Vref_volt 5//v cal
#define VOLTAGE_MIN   65
#define VOLTAGE_MAX   110
#define R1_VOLT       100000.0f// voltage divider
#define R2_VOLT       1600.0f// voltage divider

  //  I-sensor
#define Vref_I 5// i cal
#define CURRENT_MAX   100
#define I_sensor_offset 2.497559 // 2.495117 //2.493896//2.497559 //2.5//2.493896484375//2.4951171875
#define I_sensor_sensitivity 0.002857


#define TEMP_MAX      40.0f
#define TEMP_MIN      -40.0f

/* User includes (#include below this line is not maintained by Processor Expert) */


  uint8_t bit[8],motor_bit;//for contactor status
  //uint8_t mode[8];// for mode active
  uint8_t bms_state;

  //PDU-VCU TX MSG //
  uint8_t tx_status[8];
  uint8_t tx_temp[8];
  uint8_t tx_fault[8];


  //V-I
  float input_voltage,output_voltage;//,fault_vmin,fault_vmax,fault_i;
  float voltage_I =0,voltage_in_adc;
// int c=0,adc_current_avg;
  //LPTIMER
  volatile uint8_t flag_50ms=0;
  volatile uint8_t timer_50ms_counter = 0;

  //ADC
  uint16_t  adc_current; //adc_current_arr[10],;
  uint16_t adc_voltage_in;
  uint16_t adc_voltage_out = 0;
  uint16_t adc_temp[4];

  float  current_value = 0;
  int current_print;
  float voltage_out_value = 0.0f;
  uint8_t temp_value[4];
  uint8_t temp_busbar1 = 0;
  uint8_t temp_busbar2 = 0;
  uint8_t temp_busbar3 = 0;

  //fault status value
       static bool fault_overvoltage = 0;
	   static bool fault_undervoltage = 0;
	   static bool fault_overtemp = 0;
	   static bool fault_undertemp = 0;
	   static bool fault_overcurrent =0;

  bool fault_occurred = 0,adc_start=true;

//fault send
//  volatile bool fault_present = false;
//  volatile bool fault_changed = 0;
//  volatile bool fault_tempocc = 0;

  //adcfunction callback
  volatile bool adc0_conversion_complete = false;
  volatile bool adc1_conversion_complete = false;
  volatile bool first_msgvcu = false;
  volatile bool dcdc_msg = false;
  //adc_temp
  uint16_t adc_value[4];


  char tx_buff[125];

  //Temp cal
   float R1 = 10000;
   float logR2, R2, T;
   float T1;
   float c1  = 1.137946915e-03, c2 = 2.326894292e-04, c3 = 0.9333051145e-07;
   int Vo;


   // pdu to dc-dc
   uint8_t dc_dc_sndbyte[8];//to sewnd to dc-dc to turn on ,set voltage etc

   uint8_t dcdc_Overtemp=0;       // fault status start
   uint8_t dcdc_Output_overcurrent=0;
   uint8_t dcdc_Output_overvoltage =0;
   uint8_t dcdc_Output_undervoltage = 0;
   uint8_t dcdc_Input_overvoltage=0;
   uint8_t dcdc_Input_undervoltage =0;
   uint8_t dcdc_Outputshortcircuit = 0;
   uint8_t dcdc_Internal_fault = 0;
   uint8_t dcdc_communication_fault = 0;  //fault statys end

   float dcdc_current=0;//feedback by dcdc to pdu
   float dcdc_voltage=0;
   int dcdc_workingstatus;
   uint8_t dcdc_temp=0;

  //int I_fault,V_maxfault,V_minfault,temp_Maxfault,temp_Minfault;

  flexcan_data_info_t can2_data_init;//can2 for pdu-vcu & dc-dc to pdu
  flexcan_msgbuff_t rx_can2_data_ext;
//  flexcan_msgbuff_t rx_mode_msg;

// intialization
 // status_t Can_Config=1;
  status_t can_initcheck=1,can_txmbcheck=1,can_rxmbcheck=1;
  status_t lp_uart=1;
  int counter =0,can_init_success;
  int max_counter=5;

  void can0_callback(uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t *flexcanState);
 // void can2_callback(uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t *flexcanState);
  void adc0_callback(void);
  void adc1_callback(void);
  void volt_I(void);
  void temp_calc(void);
  void check_fault(void);
  void dcdc_sndmsg(void);// from pdu to dc-dc
  void dcdc_recvmsg(void);//from dc-dc to pdu
  void Pdu_initfail(void);
  void fault_sndmsg(void);

  void Lp_timerflag(void)
  {

     if(first_msgvcu== true)
     {
	 // FLEXCAN_DRV_Send(INST_CANCOM1,3U,&can2_data_init,0x1821A055,tx_fault);
      // FLEXCAN_DRV_Send(INST_CANCOM2,3U,&can2_data_init,0x1821A055,tx_fault);

      fault_sndmsg();
	  flag_50ms =1;
	  timer_50ms_counter++;

	  if(timer_50ms_counter==4)
	  {
		 // FLEXCAN_DRV_Send(INST_CANCOM1,1U,&can2_data_init,0x1821FFD9,tx_status);// to vcu
		  FLEXCAN_DRV_Send(INST_CANCOM2,1U,&can2_data_init,0x1821FFD9,tx_status);
		  //FLEXCAN_DRV_Send(INST_CANCOM1,2U,&can2_data_init,0x1821FFF0,tx_temp);// to vcu
		//  FLEXCAN_DRV_Send(INST_CANCOM2,2U,&can2_data_init,0x1821FFF0,tx_temp);
		 // FLEXCAN_DRV_Send(INST_CANCOM1,4U,&can2_data_init,0x1800F5E5,dc_dc_sndbyte);//to dcdc
		  //FLEXCAN_DRV_Send(INST_CANCOM2,4U,&can2_data_init,0x1800F5E5,dc_dc_sndbyte);
		  timer_50ms_counter=0;
	  }
	  }
	  LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);
  }


  void timer_configuration(void){
    LPTMR_DRV_Init(INST_LPTMR1, &lpTmr1_config0,1);//how to get startCounter

    INT_SYS_InstallHandler(LPTMR0_IRQn ,Lp_timerflag,NULL);
    INT_SYS_EnableIRQ(LPTMR0_IRQn);

    LPTMR_DRV_StartCounter(INST_LPTMR1);
    LPTMR_DRV_SetInterrupt(INST_LPTMR1,1);//for 50ms
  }


  void PDB_config(void)
  {
	  //PDB for ADC0
	  PDB_DRV_Init(INST_PDB1, &pdb1_InitConfig0);


	  PDB_DRV_ConfigAdcPreTrigger(INST_PDB1,0U , &pdb1_AdcTrigInitConfig0);
	  PDB_DRV_ConfigAdcPreTrigger(INST_PDB1,0U , &pdb1_AdcTrigInitConfig1);
	  PDB_DRV_ConfigAdcPreTrigger(INST_PDB1,0U , &pdb1_AdcTrigInitConfig2);
	  PDB_DRV_ConfigAdcPreTrigger(INST_PDB1,0U , &pdb1_AdcTrigInitConfig3);
	  PDB_DRV_ConfigAdcPreTrigger(INST_PDB1,0U , &pdb1_AdcTrigInitConfig4);
	  PDB_DRV_ConfigAdcPreTrigger(INST_PDB1,0U , &pdb1_AdcTrigInitConfig5);

	  PDB_DRV_LoadValuesCmd(INST_PDB1);
	  PDB_DRV_Enable(INST_PDB1);

	  PDB_DRV_SoftTriggerCmd(INST_PDB1);

	  //PDB for ADC1
	  PDB_DRV_Init(INST_PDB2, &pdb2_InitConfig0);


	  PDB_DRV_ConfigAdcPreTrigger(INST_PDB2,0U , &pdb2_AdcTrigInitConfig0);

	  PDB_DRV_LoadValuesCmd(INST_PDB2);
	  PDB_DRV_Enable(INST_PDB2);


	  PDB_DRV_SoftTriggerCmd(INST_PDB2);
  }

  void adc0_configuration(void){

//	  adc_average_config_t avg_avd0;
//	  avg_avd0.hwAvgEnable = true;
//	  avg_avd0.hwAverage= ADC_AVERAGE_32;

    ADC_DRV_ConfigConverter(INST_ADCONV1, &adConv1_ConvConfig0);

   // ADC_DRV_GetHwAverageConfig(INST_ADCONV1,&avg_avd0);
    ADC_DRV_ConfigHwAverage(INST_ADCONV1, &adConv1_HwAvgConfig0);
    ADC_DRV_AutoCalibration(INST_ADCONV1);



    ADC_DRV_ConfigChan(INST_ADCONV1, 0U, &adConv1_ChnConfig0);//thermistor1
    ADC_DRV_ConfigChan(INST_ADCONV1, 1U, &adConv1_ChnConfig1);//voltage_in
    ADC_DRV_ConfigChan(INST_ADCONV1, 2U, &adConv1_ChnConfig2);//thermistor2
    ADC_DRV_ConfigChan(INST_ADCONV1, 3U, &adConv1_ChnConfig3);//thermistor3
    ADC_DRV_ConfigChan(INST_ADCONV1, 4U, &adConv1_ChnConfig4);//thermistor4
    ADC_DRV_ConfigChan(INST_ADCONV1, 5U, &adConv1_ChnConfig5);//I_ADC


    INT_SYS_InstallHandler(ADC0_IRQn,&adc0_callback,NULL);
    INT_SYS_EnableIRQ(ADC0_IRQn);
  }

  void adc1_configuration(void){
	  ADC_DRV_ConfigConverter(INST_ADCONV2, &adConv2_ConvConfig0);
	  ADC_DRV_AutoCalibration(INST_ADCONV2);

	  ADC_DRV_ConfigChan(INST_ADCONV2,0U, &adConv2_ChnConfig0);//v_out
	  //ADC_DRV_ConfigChan(INST_ADCONV2,1U, &adConv2_ChnConfig1);//thermistor6

	  INT_SYS_InstallHandler(ADC1_IRQn,&adc1_callback,NULL);
	  INT_SYS_EnableIRQ(ADC1_IRQn);

  }

  void adc0_callback(void){
	  ADC_DRV_GetChanResult(INST_ADCONV1,0U,&adc_temp[0]);
 	  ADC_DRV_GetChanResult(INST_ADCONV1,1U,&adc_voltage_in);
	  ADC_DRV_GetChanResult(INST_ADCONV1,2U,&adc_temp[1]);
	  ADC_DRV_GetChanResult(INST_ADCONV1,3U,&adc_temp[2]);
	  ADC_DRV_GetChanResult(INST_ADCONV1,4U,&adc_temp[3]);
	  ADC_DRV_GetChanResult(INST_ADCONV1,5U,&adc_current);
//	  adc_current_arr[c]=adc_current;
//	  c++;
	  adc0_conversion_complete = true;
  }

 void adc1_callback(void){
	 ADC_DRV_GetChanResult(INST_ADCONV2,0U,&adc_voltage_out);
	// ADC_DRV_GetChanResult(INST_ADCONV2,1U,&adc1_temp[0]);
	 adc1_conversion_complete = true;

 }

 void temp_calc(void){

    for(int i =0; i<4; i++){
    	Vo=adc_temp[i];


    	if (Vo > 0 && Vo < 4095) {
    	       //R2 = R1 * (4095.0 / (float)Vo - 1.0);
    		R2 = R1 / ((4095.0f / (float)Vo) - 1.0f);

    	        if (R2 > 0) {
    	            logR2 = log(R2);
    	           T = (1.0 / (c1 + c2*logR2 + c3*logR2*logR2*logR2));
    	           temp_value[i]  = T - 273.15; // Convert to Celsius
    	        }
    	}
    }
 }


 void volt_I(void)
 {
	 //I sensor calc
//	 static  float current_value = 0;
//	static  float input_voltage  = 0;
//	 s tatic  float output_voltage = 0;

	  voltage_I = (adc_current* Vref_I)/4096.0f;//adc_current
	 current_value = (voltage_I -I_sensor_offset )/I_sensor_sensitivity;
	 current_print= current_value *10;//print in uart

//  if(current_value<=0.5 && current_value >=-2){//filter intial random data
//	current_value=0;
//	 current_print= current_value *10;//print in uart
//}
	 //Vin cal
	 voltage_in_adc = (adc_voltage_in *Vref_volt)/4096.0f;
     input_voltage = (voltage_in_adc)*((R1_VOLT+R2_VOLT)/R2_VOLT);
     input_voltage =input_voltage/2;

	 //vout cal
	 voltage_out_value = (adc_voltage_out *Vref_volt)/4096.0f;
	 output_voltage = (voltage_out_value)*((R1_VOLT+R2_VOLT)/R2_VOLT);
	 output_voltage = output_voltage/2;//amplifier present so /2
//
//	 sprintf(tx_buff,"adc_voltin : %d, adc_voltout : %d, adc_I: %d , voltage_in : %d , voltage_out : %d, Current_value : %d\r\n",adc_voltage_in,adc_voltage_out,(uint16_t)adc_current,(uint16_t)input_voltage,(uint16_t)output_voltage,current_print);
//	 LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));

 }

 void check_fault(void)
 {
//	     bool prev_overcurrent = fault_overcurrent;
//	     bool prev_overvoltage = fault_overvoltage;
//	     bool prev_undervoltage = fault_undervoltage;
//	     bool prev_overtemp = fault_overtemp;
//	     bool prev_undertemp = fault_undertemp;



	 //if(fabs(current_value) >= 100){//(float)CURRENT_MAX){// ||current_value <= -CURRENT_MAX ){
	 if(current_value >= 100){
	 fault_overcurrent = 1;
//		I_fault++;
//		fault_i=current_value;
	 if(fault_overcurrent){
	 sprintf(tx_buff,"adc_I: %d,Current_value : %d\r\n",(uint16_t)adc_current,current_print);
	 LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));
	}
 }
	if(input_voltage >= VOLTAGE_MAX){
		fault_overvoltage = 1;
//		  V_maxfault++;
//		  fault_vmax=input_voltage;

	}
	if(input_voltage <= VOLTAGE_MIN){//if(input_voltage > 0 && input_voltage <VOLTAGE_MIN) {// for the intial start ,if battery is not on
		fault_undervoltage=1;
     if(fault_undervoltage){
		sprintf(tx_buff,"adc_voltin : %d, adc_voltout : %d,voltage_in : %d , voltage_out : %d\r\n",adc_voltage_in,adc_voltage_out,(uint16_t)input_voltage,(uint16_t)output_voltage);
		LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));
	  }
	}
//	fault_overtemp = 0;
//	fault_undertemp = 0;

	for(uint8_t i =0;i<4;i++){
		if(temp_value[i] > TEMP_MAX){
			fault_overtemp =1;
           //temp_Maxfault ++;
		}
		if(temp_value[i] < TEMP_MIN){
			fault_undertemp =1;
			// temp_Minfault++;
		}
	}

	     tx_fault[0] = can_rxmbcheck;
		 tx_fault[1] = (fault_overcurrent << 0) | (fault_overvoltage << 1) | (fault_undervoltage << 2) | (fault_overtemp << 3) | (fault_undertemp <<4) ;
		 tx_fault[2] = (dcdc_Overtemp << 0)|(dcdc_Output_overcurrent << 1) | (dcdc_Output_overvoltage << 2) | (dcdc_Output_undervoltage << 3) | (dcdc_Input_overvoltage << 4) | (dcdc_Input_undervoltage << 5) | (dcdc_Outputshortcircuit << 6) | (dcdc_Internal_fault  << 7);
		 tx_fault[3] = dcdc_communication_fault;
		 tx_fault[4] = 0;
		 tx_fault[5] = 0;
		 tx_fault[6] = 0;
		 tx_fault[7] = 0;

//		 if(prev_overcurrent != fault_overcurrent || prev_overvoltage != fault_overvoltage ||  prev_undervoltage != fault_undervoltage ||  prev_overtemp != fault_overtemp || prev_undertemp != fault_undertemp) {
//			 fault_changed = true;
//		     }
//	sprintf(tx_buff,"I_COUNT : %d, VMAXCOUNT : %d, VMINCOUNT: %d , TEMPMAXCOUNT : %d , TEMPMINCOUNT : %d,fault_i:%d, fault_vmin : %d ,fault_vmax V_\r\n",I_fault,V_maxfault,V_minfault,temp_Maxfault,temp_Minfault,fault_i,fault_vmin,fault_vmax);
//	LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));
 }

 void status_sendmsg(void)
 {

	 tx_status[0] = (bit[0]<<0) |(bit[1]<<1) | (bit[2]<<2) | (bit[3]<<3); // contactor status

	 int16_t current_scaled= (int16_t)(current_value * 10.0f);
	 //uint16_t current_int= (uint16_t)((current_value * 10.0f)+5000); // CURRENT VALUE
	 uint16_t current_int= (uint16_t)(current_scaled + 5000);
	 tx_status[1] = (uint8_t) (current_int & 0xFF);//lsb
	 tx_status[2] = (uint8_t) ((current_int >> 8) & 0xFF); //-msb

	 uint16_t voltage_int = (uint16_t)(input_voltage * 10.0f);// voltage_in value
	 tx_status[3] =  (voltage_int & 0xFF);//lsb
	 tx_status[4] = (voltage_int >> 8);// & 0xFF);//msb

	 uint16_t voltage_out_int = (uint16_t)(output_voltage * 10.0f); //voltage_out value
	 tx_status[5] =  (voltage_out_int & 0xFF);//lsb
	 tx_status[6] = (voltage_out_int >> 8) ;//& 0xFF);//msb

	 //tx_status[7] = (tx_fault[0] << 0) | (tx_fault[1]<<1) | (tx_fault[2]<<2) | (tx_fault[3]<<3) | (tx_fault[4] << 4); // FAULT STATUS
	 tx_status[7]=(fault_overcurrent << 0) | (fault_overvoltage << 1) | (fault_undervoltage << 2) | (fault_overtemp << 3) | (fault_undertemp) ;

	 //Temp status msg

	 uint8_t temp_int[4];
	 for(uint8_t i =0;i<4;i++){
	 temp_int[i] = (uint8_t)(temp_value[i] + 40.0f);
	 }

	 //adc_test= adc_temp[0]/16;
	 tx_temp[0]=temp_int[0];
	 tx_temp[1]=temp_int[1];
	 tx_temp[2]=temp_int[2];
	 tx_temp[3]=temp_int[3];
	 tx_temp[4]=0; // reserved
	 tx_temp[5]=0; // reserved
	 tx_temp[6]=0; // reserved
	 tx_temp[7]=0; // reserved

	 //tx_temp[0]=temp_value[0]; // reserved
	 //	 tx_temp[1]= temp_value[1];// reserved
	 //	 tx_temp[2]= temp_value[2];// reserved
	 //	 tx_temp[3]= temp_value[3];//
	 if(motor_bit){
		 if(output_voltage>80){
			 bit[0]=1;
		 }
	 }
	 else{
		 bit[0]=0;
	 }
 }

 void fault_sndmsg(void)
 {
	 tx_fault[0] = can_rxmbcheck;
	 tx_fault[1] = (fault_overcurrent << 0) | (fault_overvoltage << 1) | (fault_undervoltage << 2) | (fault_overtemp << 3) | (fault_undertemp << 4) ;
	 tx_fault[2] = (dcdc_Overtemp << 0)|(dcdc_Output_overcurrent << 1) | (dcdc_Output_overvoltage << 2) | (dcdc_Output_undervoltage << 3) | (dcdc_Input_overvoltage << 4) | (dcdc_Input_undervoltage << 5) | (dcdc_Outputshortcircuit << 6) | (dcdc_Internal_fault  << 7);
	 tx_fault[3] = dcdc_communication_fault;;
	 tx_fault[4] = 0;
	 tx_fault[5] = 0;
	 tx_fault[6] = 0;
	 tx_fault[7] = 0;

	 if(first_msgvcu){
	   if(tx_fault[0] || tx_fault[1] || tx_fault[2] || tx_fault[3]){
		 FLEXCAN_DRV_Send(INST_CANCOM2,3U,&can2_data_init,0x1821A055,tx_fault);
	   }

	 if(fault_overtemp){
		 FLEXCAN_DRV_Send(INST_CANCOM1,2U,&can2_data_init,0x1821FFF0,tx_temp);
	   }
	 }
 }

 void Pdu_initfail()
 {
   if(counter>=5){
	 if(can_initcheck==1)
	 {
		// tx_buff[0]==1;//to send uart -can initailization failed
//		 sprintf(tx_buff,"CAN intialization failed\r\n");
//		 LPUART_DRV_SendData(INST_LPUART1,(uint8_t *)tx_buff,strlen(tx_buff));
	 }
	 if(can_txmbcheck==1)
	 {
		// tx_buff[1]==1;
		// tx_fault[0]==1;
//		 sprintf(tx_buff,"CAN txmb config failed\r\n");
//		 LPUART_DRV_SendData(INST_LPUART1,(uint8_t *)tx_buff,strlen(tx_buff));

	 }
	 if(can_rxmbcheck==1)
	 {
		 //tx_buff[2]==1;
//		 sprintf(tx_buff,"CAN rxmb config failed\r\n");
//		 LPUART_DRV_SendData(INST_LPUART1,(uint8_t *)tx_buff,strlen(tx_buff));
	 }
   }
 }

 void dcdc_sndmsg(void)
 {
	 dc_dc_sndbyte[0]=0x00;

	 if(bit[2]==1){
		 dc_dc_sndbyte[1]=0x01; //turn on dc-dc converter after or when vcu send on msg to pdu
	 }
	 else{
		 dc_dc_sndbyte[1]=0x00;
	 }

	 dc_dc_sndbyte[2]=0x8C;//output voltage 14x10=140
	 dc_dc_sndbyte[3]=0x00;

	 dc_dc_sndbyte[4]=0x58;//CURRENT 60*10A=600A
	 dc_dc_sndbyte[5]=0x02;

	 dc_dc_sndbyte[6]=0x00;
	 dc_dc_sndbyte[7]=0x00;

 }

 void dcdc_recvmsg(void)
 {
    if(dcdc_msg)
    {
    	uint8_t dcdc_faultbyte1 = rx_can2_data_ext.data[1];
        uint8_t dcdc_faultbyte2 = rx_can2_data_ext.data[2];

         dcdc_Overtemp =  (dcdc_faultbyte1 >> 0) & 0x01;
    	 dcdc_Output_overcurrent= (dcdc_faultbyte1 >> 1) & 0x01;
    	 dcdc_Output_overvoltage = (dcdc_faultbyte1 >> 2) & 0x01;
    	 dcdc_Output_undervoltage = (dcdc_faultbyte1 >> 3) & 0x01;
    	 dcdc_Input_overvoltage=(dcdc_faultbyte1 >> 4) & 0x01;
    	 dcdc_Input_undervoltage = (dcdc_faultbyte1 >> 5) & 0x01;
    	 dcdc_Outputshortcircuit = (dcdc_faultbyte1 >> 6) & 0x01;
    	 dcdc_Internal_fault = (dcdc_faultbyte1 >> 7) & 0x01;

    	 dcdc_communication_fault = (dcdc_faultbyte2 >> 0) & 0x01;

    	 uint16_t dcdc_currentraw = (uint16_t) (rx_can2_data_ext.data[3]  | (rx_can2_data_ext.data[4] << 8));
    	 dcdc_current = ((float)dcdc_currentraw) * 0.1f;

    	 uint8_t dcdc_voltageraw = rx_can2_data_ext.data[5];
    	 dcdc_voltage = ((float)dcdc_voltageraw) * 0.2f;

    	  dcdc_workingstatus = rx_can2_data_ext.data[6];

    	   uint8_t dcdc_temp = rx_can2_data_ext.data[7];
    	   dcdc_temp = dcdc_temp - 40;

//    	   sprintf(tx_buff," DCDC_CURRENT: %d, DCDC_VOLT : %d, STATUS: %d , DCDC_TEMP : %d\r\n",dcdc_current,dcdc_voltage,dcdc_workingstatus,dcdc_temp);
//    	   LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));
    }
 }

 void can0_config(){

	 while((can_initcheck || can_txmbcheck || can_rxmbcheck))//||(can_rxmbcheck ^ can_initcheck ^ can_txmbcheck))
	 {
		 if(counter>max_counter)
			 	    {//hjhg=1;
			 	    	break;
			 	    }
			  can_initcheck= FLEXCAN_DRV_Init(INST_CANCOM2, &canCom2_State, &canCom2_InitConfig0);

		 	    can2_data_init.data_length=8;
		 	    can2_data_init.is_remote=false;
		 	    can2_data_init.msg_id_type=FLEXCAN_MSG_ID_EXT;

		 	  can_txmbcheck= FLEXCAN_DRV_ConfigTxMb(INST_CANCOM2,1U,&can2_data_init,0x0);
		 	  can_rxmbcheck=FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2,6U,&can2_data_init,0x1821D9A0);

		 	 //can_rxmbcheck=FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2,6U,&can2_data_init,0x0);
		 	     counter++;
		 	 }
 	   FLEXCAN_DRV_ConfigRxMb(INST_CANCOM2,8U,&can2_data_init,0x18F0E5F6);
 	  	FLEXCAN_DRV_SetRxMaskType(INST_CANCOM2,FLEXCAN_RX_MASK_INDIVIDUAL );
 	 	// FLEXCAN_DRV_SetRxMaskType(INST_CANCOM2,FLEXCAN_RX_MASK_GLOBAL );
 	  	//FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM2,FLEXCAN_MSG_ID_EXT,0x0);
 	     FLEXCAN_DRV_SetRxIndividualMask(INST_CANCOM2,FLEXCAN_MSG_ID_EXT,6U, 0x1FFFFFFF);
 	     FLEXCAN_DRV_SetRxIndividualMask(INST_CANCOM2,FLEXCAN_MSG_ID_EXT,8U, 0x1FFFFFFF);

 	  	 FLEXCAN_DRV_InstallEventCallback(INST_CANCOM2,(flexcan_callback_t)&can0_callback,NULL);
 	  	 FLEXCAN_DRV_Receive(INST_CANCOM2,6U,&rx_can2_data_ext); //from dc-dc to pdu fault msg
 	 	 FLEXCAN_DRV_Receive(INST_CANCOM2,8U,&rx_can2_data_ext);
   }

//  void can2_configuration(){
//
////	  status_t can_initcheck = STATUS_ERROR;
////	  status_t can_txmbcheck = STATUS_ERROR;
////	  status_t can_rxmbcheck = STATUS_ERROR;
//
//	  while((can_initcheck || can_txmbcheck || can_rxmbcheck))//||(can_rxmbcheck ^ can_initcheck ^ can_txmbcheck))
//	  {
//	    if(counter>max_counter)
//	    {//hjhg=1;
//	    	break;
//	    }
//	   can_initcheck=FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0);
//
//     	can2_data_init.data_length=8;
//     	can2_data_init.is_remote=false;
//      	can2_data_init.msg_id_type=FLEXCAN_MSG_ID_EXT;
//
//      	can_txmbcheck=FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1,1U,&can2_data_init,0x0);// for Status msg
//      	can_rxmbcheck=FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,6U,&can2_data_init,0x1823567);
//
//    	//can_init_success=0;
//    	counter++;
//	  }
//
//     	FLEXCAN_DRV_SetRxMaskType(INST_CANCOM1, FLEXCAN_RX_MASK_GLOBAL);
//     	FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM1,FLEXCAN_MSG_ID_EXT,0x0);
//
//        FLEXCAN_DRV_InstallEventCallback(INST_CANCOM1,(flexcan_callback_t)&can2_callback,NULL);
//     	FLEXCAN_DRV_Receive(INST_CANCOM1,6U,&rx_can2_data_ext);//index how
//     	//FLEXCAN_DRV_Receive(INST_CANCOM1,5U,&rx_can2_data_ext);
//     	//can_init_success=1;
//  }

//  void can2_callback(uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t *flexcanState)
//      {
//      	(void) flexcanState;
//
//      	(void) instance;
//
//      	switch (eventType){
//
//      	case  FLEXCAN_EVENT_RX_COMPLETE:
//      	{
//      		FLEXCAN_DRV_Receive(INST_CANCOM1,6U,&rx_can2_data_ext);
//      		//FLEXCAN_DRV_Receive(INST_CANCOM1,5U,&rx_can2_data_ext);
//
//      		if(rx_can2_data_ext.msgId == 0x1821D9A0) // load control state
//      		{
//
//              first_msgvcu = true;
//
//      			if(rx_can2_data_ext.data[0]==1)
//      			{
//                      PINS_DRV_SetPins(PTB,1<<10);// ptb 10 for motor controller
//                      //PINS_DRV_SetPins(PTC,1<<2);
//                       bit[0]=1;
//      			}
//      			else
//      			{
//      				PINS_DRV_ClearPins(PTB,1<<10);
//      				bit[0]=0;
//      			}
////      			if(rx_can2_data_ext.data[1]==1){
////      			      //PINS_DRV_SetPins(PTB,1<<10);
////      			      bit[1]=1;
////      			  }else{
////      			   // PINS_DRV_ClearPins(PTB,1<<10);//ptc 9 not in excel for HVAC
////      			    bit[1]=0;
////      			  }
//      			if(rx_can2_data_ext.data[2]==1){
//      	    		 PINS_DRV_SetPins(PTC,1<<3);// PTC 3 for DC-DC converter
//      	    		 bit[2]=1;
//      	    	}else{
//      	    		PINS_DRV_ClearPins(PTC,1<<3);
//      	    		 bit[2]=0;
//      	    		}
//      			if(rx_can2_data_ext.data[3]==1){
//        			 PINS_DRV_SetPins(PTD,1<<9);// PTD 9 for charger
//        			 bit[3]=1;
//				 }
//      			else{
//					PINS_DRV_ClearPins(PTD,1<<9);
//					bit[3]=0;
//				 }
//      		    }
//
//      		//FLEXCAN_DRV_Receive(INST_CANCOM2,6U,&rx_can2_data_ext);
//
//      		if(rx_can2_data_ext.msgId==0x1800E5F5)
//      		{
//      		  dcdc_msg=true;
//      		}
//      		break;
//      	   }
//      	}
//      }

  void can0_callback(uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t *flexcanState)
  {
	  (void)flexcanState;

	  (void)instance;

	  switch(eventType){

	  case FLEXCAN_EVENT_RXFIFO_OVERFLOW:
	  	  	  	    {
	  	  	  	  break;
	  	  	  	    }


	  case FLEXCAN_EVENT_TX_COMPLETE:
	  	  	    {
	  	  	    break;
	  	  	    }


	  case FLEXCAN_EVENT_RXFIFO_WARNING:
	  	    {
	  	    break;
	  	    }


	  case FLEXCAN_EVENT_RX_COMPLETE:
	    {
	    	FLEXCAN_DRV_Receive(INST_CANCOM2,6U,&rx_can2_data_ext);
	    	 FLEXCAN_DRV_Receive(INST_CANCOM2,8U,&rx_can2_data_ext);

	    		switch(rx_can2_data_ext.msgId)
	    				{


	    					case 0x1821D9A0 :// load control state
	    							{

	    								rx_can2_data_ext.msgId=0;
	    									first_msgvcu = true;

	    								if(rx_can2_data_ext.data[0]==1)
	    								{
										  PINS_DRV_SetPins(PTB,1<<10);// ptb 10 for motor controller
										  //PINS_DRV_SetPins(PTC,1<<2);
										  // bit[0]=1;
										  motor_bit=1;
	    								}
	    								else
	    								{
	    									PINS_DRV_ClearPins(PTB,1<<10);
	    									bit[0]=0;
	    									//motor_bit=0;
	    								}
	    								if(rx_can2_data_ext.data[2]==1){
											 PINS_DRV_SetPins(PTC,1<<3);// PTC 3 for DC-DC converter
											 bit[2]=1;
	    								}
	    								else
	    									{
	    									PINS_DRV_ClearPins(PTC,1<<3);
	    									bit[2]=0;
	    									}
	    								if(rx_can2_data_ext.data[3]==1){
											 PINS_DRV_SetPins(PTD,1<<9);// PTD 9 for charger
											 bit[3]=1;
											 }
	    								else
	    									{
	    									PINS_DRV_ClearPins(PTD,1<<9);
	    									bit[3]=0;
	    									}
	    								break;
	    								}
	    	   // memset(rx_can2_data_ext.data,0,sizeof(rx_can2_data_ext.data));
	    											//FLEXCAN_DRV_Receive(INST_CANCOM2,6U,&rx_can2_data_ext);

	    					case 0x18F0E5F6 :
	    								{
	    									rx_can2_data_ext.msgId=0;
											  bms_state=rx_can2_data_ext.data[0];
											  break;
	    								}

	    	  }
	   	}
	  }
  }

/*! 
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
*/
int main(void)
 {
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/

  /* Write your code here */
    CLOCK_DRV_Init(&clockMan1_InitConfig0);
    PINS_DRV_Init(NUM_OF_CONFIGURED_PINS, g_pin_mux_InitConfigArr);

    PINS_DRV_SetPins(PTC,1<<2);//Battery neg
    OSIF_TimeDelay(100);
    PINS_DRV_SetPins(PTE,1<<0);//HIGH TO USE CAN 2
    OSIF_TimeDelay(100);
    PINS_DRV_SetPins(PTE,1<<1);//HIGH TO USE CAN 0
    OSIF_TimeDelay(100);
    PINS_DRV_SetPins(PTE,1<<15);// Discharge NAND Gate  Reset
    OSIF_TimeDelay(100);
    PINS_DRV_SetPins(PTE,1<<16);//Charge NAND Gate  Reset
    OSIF_TimeDelay(100);

   // can2_configuration();
    can0_config();
    PDB_config();
    adc0_configuration();
    adc1_configuration();
    timer_configuration();
   //Pdu_initfail();
    //can0_config();

    lp_uart =LPUART_DRV_Init(INST_LPUART1, &lpuart1_State, &lpuart1_InitConfig0);
//    PDB_DRV_SoftTriggerCmd(INST_PDB1);
//    PDB_DRV_SoftTriggerCmd(INST_PDB2);

    INT_SYS_SetPriority(CAN0_ORed_IRQn,0);
   // INT_SYS_SetPriority(CAN2_ORed_IRQn,0);
    INT_SYS_SetPriority(LPTMR0_IRQn,1);


    while(1){
    if( (bms_state==5 || bms_state==6) ){
        		if(adc_start){
        			 adc_start=false;
        			 OSIF_TimeDelay(500);
        	    	 PDB_DRV_SoftTriggerCmd(INST_PDB1);
        	    	 PDB_DRV_SoftTriggerCmd(INST_PDB2);

        		}
        	}
        	   if(adc0_conversion_complete == true)
        	    	{
    //    		if( (bms_state==5 || bms_state==6) ){
    //    			 PDB_DRV_SoftTriggerCmd(INST_PDB1);
    //    			  PDB_DRV_SoftTriggerCmd(INST_PDB2);


        			//  OSIF_TimeDelay(1);
        		         volt_I();
        	    	   temp_calc();

        	    	   check_fault();


        	    	   adc0_conversion_complete = false;
        	    	   PDB_DRV_SoftTriggerCmd(INST_PDB1);
        	    	   //adc0_conversion_complete = false;
        	    	}

        	if(adc1_conversion_complete == true)
        	    	{
        		        adc1_conversion_complete = false;
        	    		PDB_DRV_SoftTriggerCmd(INST_PDB2);
        	    	//	adc1_conversion_complete = false;
        	    	}
        	 status_sendmsg();
    }
  /* For example: for(;;) { } */

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
