/*
 * lptimer.c
 *
 *  Created on: 04-Dec-2025
 *      Author: Tarun
 */
#include "lptimer.h"
void timer_for_10ms(){

  sending_data_to_brake();

  if(send_data_to_pdu_flag==1){
		pdu.count++;
	if(pdu.count>=10){
		sending_data_to_pdu();
		pdu.count=0;
	}
  }

  obc.count++;
  if( obc.count>=10){
	sending_data_to_obc();
	 obc.count=0;
	 if(pid_enable==1){
	        Input=mcu.rpm;
	 		PID_Compute(&TPID);
	 		MCP4921_SetOutput((uint16_t)Output);
	 		snprintf(tx_buff, sizeof(tx_buff), "Output: %d,\r\n", (uint16_t)Output);
	 		LPUART_DRV_SendData(INST_LPUART1,tx_buff,strlen(tx_buff));
	 		//press_bar=0;
	  }
  }

 LPTMR_DRV_ClearCompareFlag(INST_LPTMR1);
}
void timmer_config(){
  	LPTMR_DRV_Init(INST_LPTMR1, &lpTmr1_config0,1);
  	INT_SYS_InstallHandler(LPTMR0_IRQn,timer_for_10ms,NULL);

  	INT_SYS_EnableIRQ(LPTMR0_IRQn);

  	LPTMR_DRV_StartCounter(INST_LPTMR1);
  	LPTMR_DRV_SetInterrupt(INST_LPTMR1,1);


  }
