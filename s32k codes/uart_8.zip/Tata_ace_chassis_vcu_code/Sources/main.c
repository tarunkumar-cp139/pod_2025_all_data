/* ###################################################################
**     Filename    : main.c
**     Processor   : S32K1xx
**     Abstract    :
**         Main module.
**         This module contains user's application code.
**     Settings    :
**     Contents    :
**         No public methods
**
** ###################################################################*/
/*!
** @file main.c
** @version 01.00
** @brief
**         Main module.
**         This module contains user's application code.
*/         
/*!
**  @addtogroup main_module main module documentation
**  @{
*/         
/* MODULE main */


/* Including necessary module. Cpu.h contains other modules needed for compiling.*/
#include "main.h"
  volatile int exit_code = 0;

/* User includes (#include below this line is not maintained by Processor Expert) */


uint8_t can_data_1[8]={0xA1,0x02,0x03,0x04,0x05,0xB6,0x7A,0x1A};
/*! 
  \brief The main function for the project.
  \details The startup initialization sequence is the following:
 * - startup asm routine
 * - main()
*/
int main(void)
{
  /* Write your local variable definition here */

  /*** Processor Expert internal initialization. DON'T REMOVE THIS CODE!!! ***/
  #ifdef PEX_RTOS_INIT
    PEX_RTOS_INIT();                   /* Initialization of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of Processor Expert internal initialization.                    ***/
//CLOCK_DRV_Init(&clockMan1_InitConfig0);
    syst_clk();
    pin_config();
    can0_config();
    can1_config();
    can2_config();
    uart0_config();
    spi0_config();
    timmer_config();
    pid_config();
    PINS_DRV_SetPins(PTE,1<<1);
    PINS_DRV_SetPins(PTE,1<<0);

	INT_SYS_SetPriority(CAN0_ORed_IRQn,0);
	INT_SYS_SetPriority(CAN1_ORed_IRQn,1);
	INT_SYS_SetPriority(CAN2_ORed_IRQn,2);
	INT_SYS_SetPriority(LPTMR0_IRQn,3);
while(1){
	system_states();
//	sending_data_to_brake();
//	sending_data_to_pdu();
//	 FLEXCAN_DRV_Send(INST_CANCOM1,3U,&can1_data_init, 0x180E4B2,can_data_1);
//	FLEXCAN_DRV_Send(INST_CANCOM1,8U,&can1_data_init, 0x1956590,can_data_1);
//	FLEXCAN_DRV_Send(INST_CANCOM3,9u,&can0_data_init,0x1821D8A,can_data_1);
    OSIF_TimeDelay(100);
}

  /* Write your code here */
  /* For example: for(;;) { } */

  /*** Don't write any code pass this line, or it will be deleted during code generation. ***/
  /*** RTOS startup code. Macro PEX_RTOS_START is defined by the RTOS component. DON'T MODIFY THIS CODE!!! ***/
  #ifdef PEX_RTOS_START
    PEX_RTOS_START();                  /* Startup of the selected RTOS. Macro is defined by the RTOS component. */
  #endif
  /*** End of RTOS startup code.  ***/
  /*** Processor Expert end of main routine. DON'T MODIFY THIS CODE!!! ***/
  for(;;) {
    if(exit_code != 0) {
      break;
    }
  }
  return exit_code;
  /*** Processor Expert end of main routine. DON'T WRITE CODE BELOW!!! ***/
} /*** End of main routine. DO NOT MODIFY THIS TEXT!!! ***/

/* END main */
/*!
** @}
*/
/*
** ###################################################################
**
**     This file was created by Processor Expert 10.1 [05.21]
**     for the NXP S32K series of microcontrollers.
**
** ###################################################################
*/
