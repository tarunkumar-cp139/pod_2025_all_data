/*
 * can1.c
 *
 *  Created on: 29-Oct-2025
 *      Author: Tarun
 */

#include "can1.h"///data from ALL ECU'S



flexcan_data_info_t can1_data_init,can1_data_init_std;
flexcan_msgbuff_t rx_can1_init,rx_can1_init_std;
parameter pdu= {.error=true },mcu= {.error=true },bms= {.error=true },brake= {.error=true },obc = {.error=true };

bool data_from_vcu,diagnosis_success,error_in_eps,no_error_in_imd,error_in_imd,no_error_in_dc_dc,error_in_dc_dc;
bool dc_dc_on,eps_on,imd_on,wake_up_success,diagnosis_on;
uint16_t applied_press;
char rfid_tag;

CanChecks can1 = {
	      .init_check = STATUS_ERROR,
	      .conf_tx_check = STATUS_ERROR,
	      .conf_rx_check = STATUS_ERROR,
		  .conf_rx_check_std = STATUS_ERROR,
		  .conf_tx_check_std = STATUS_ERROR,
	      .init_success = false
	  };
void can1_config(){
	//can1.init_check=1,can1.conf_tx_check=1,can1.conf_rx_check=1;
	can1_data_init.data_length= 8;
  	can1_data_init.is_remote = false;
  	can1_data_init.msg_id_type= FLEXCAN_MSG_ID_EXT;

	can1_data_init_std=can1_data_init;
	can1_data_init_std.msg_id_type =  FLEXCAN_MSG_ID_STD;

  //	while(FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0)&&FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1,2U,&can1_data_init,0x0)&&FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,5U,&can1_data_init,0x0)){
  	 while(can1.init_check && can1.conf_tx_check && can1.conf_rx_check && can1.conf_rx_check_std && can1.conf_tx_check_std){
  			  can1.init_check = FLEXCAN_DRV_Init(INST_CANCOM1, &canCom1_State, &canCom1_InitConfig0);
  			  can1.conf_tx_check =  FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1,2U,&can1_data_init, 0x184563f7);
  			  can1.conf_tx_check_std = FLEXCAN_DRV_ConfigTxMb(INST_CANCOM1,4U,&can1_data_init_std, 0x675);
  			  can1.conf_rx_check = FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,3U,&can1_data_init, 0x0);
  			  can1.conf_rx_check_std = FLEXCAN_DRV_ConfigRxMb(INST_CANCOM1,7U,&can1_data_init_std,0x0);

  			  can1.init_success=0;
  		  }


  		FLEXCAN_DRV_SetRxMaskType(INST_CANCOM1, FLEXCAN_RX_MASK_GLOBAL);
  		FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM1,FLEXCAN_MSG_ID_EXT , 0x0);
  		FLEXCAN_DRV_SetRxMbGlobalMask(INST_CANCOM1,FLEXCAN_MSG_ID_STD , 0x0);
  	  	FLEXCAN_DRV_InstallEventCallback(INST_CANCOM1, (flexcan_callback_t)&can1_callback, NULL);
  		FLEXCAN_DRV_Receive(INST_CANCOM1, 3U,&rx_can1_init);
  		FLEXCAN_DRV_Receive(INST_CANCOM1, 7U,&rx_can1_init_std);
  		can1.init_success=1;
}
void can1_callback (uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t flexcanState)
   {
 //(void)buffIdx;
   	(void)flexcanState;

   	(void) instance;

   	switch(eventType){

   	case FLEXCAN_EVENT_RX_COMPLETE:
   	{

   		FLEXCAN_DRV_Receive(INST_CANCOM1,3U,&rx_can1_init);
   		FLEXCAN_DRV_Receive(INST_CANCOM3,7U,&rx_can1_init_std);


   	 		switch (rx_can1_init.msgId){


   	 		case from_pdu ://PDU
   	 		 				{



   	 			        pdu.data[0]=rx_can1_init.data[0];
						pdu.data[1]=rx_can1_init.data[1];
						pdu.data[2]=rx_can1_init.data[2];
						pdu.data[3]=rx_can1_init.data[3];
						pdu.data[4]=rx_can1_init.data[4];
						pdu.data[5]=rx_can1_init.data[5];
						pdu.data[6]=rx_can1_init.data[6];
						pdu.data[7]=rx_can1_init.data[7];


   	 			         if(diagnosis_on==1){
   	 			        	if(pdu.data[7]==1){
   	 			            	pdu.error=1;
   	 			        	}
   	 			        	else if(pdu.data[7]==0){
   	 			        		pdu.error=0;
   	 			        	}
   	 			         }
   	 			     if(feedback_from_pdu==pdu.data[0]){
   	 			    	send_data_to_pdu_flag=0;

   	 			     }
   	 			  memset(rx_can1_init.data, 0, sizeof(rx_can1_init.data));
   	 		 		//	FLEXCAN_DRV_Send(INST_CANCOM1,8U,&can1_data_init,0x1876590,can_data_1);
   	 		 			break;
   	 		 				}

   	 		case from_bms : //BP & BMS
   	 				{

						bms.data[0]=rx_can1_init.data[0];
						bms.data[1]=rx_can1_init.data[1];
						bms.data[2]=rx_can1_init.data[2];
						bms.data[3]=rx_can1_init.data[3];
						bms.data[4]=rx_can1_init.data[4];
						bms.data[5]=rx_can1_init.data[5];
						bms.data[6]=rx_can1_init.data[6];
						bms.data[7]=rx_can1_init.data[7];
						//  in_charg++;

						bms.voltage=(bms.data[1]*256+bms.data[2]);
						bms.voltage=bms.voltage/100;
						bms.current=(bms.data[3]*256+bms.data[4]);
						bms.current=(bms.current-7000)/10;


						if(bms.data[0]==4)
						{
							send_to_bms=2;///to bms_wake_up;
							sending_data_to_bms();

						}
						else if(bms.data[0]==2)
						{
							send_to_bms=5;
							sending_data_to_bms();//to bms_discharge();
						}
//
//						else if(bms.data[0]==5)
//						{
//							bms.on=1;
////							in_discharging=1;
////							in_charging=0;
//						}
   	 				if(diagnosis_on==1){
   						if(bms.data[7]==1){
   							bms.error=0;
   						}
   						else if(bms.data[7]==0){
   							bms.error=1;
   						}
   					 }
   	 			  memset(rx_can1_init.data, 0, sizeof(rx_can1_init.data));
   	 			    // FLEXCAN_DRV_Send(INST_CANCOM1,8U,&can1_data_init, 0x1876590,can_data_1);
   	 			break;
   	 				}
   	 		case from_eps: //EPS
   	 		{
   	 					eps_on=1;
   	 					if(diagnosis_on==1){
   							if(rx_can1_init.data[7]==1){
   								error_in_eps=0;
   							}
   							else if(rx_can1_init.data[7]==0){
   								error_in_eps=1;
   							}
   						 }
   	 				  memset(rx_can1_init.data, 0, sizeof(rx_can1_init.data));
   	 		     //     FLEXCAN_DRV_Send(INST_CANCOM1,9U,&can1_data_init, 0x180E4F1,can_data_1);///mail box id should be different to all the can data that are in diff CAN's
   	 		    break;
   	 		}
   	 		case from_dc_dc ://DC-DC AUX
   	 		{
   	 				dc_dc_on=1;
   	 				if(diagnosis_on==1){
   						if(rx_can1_init.data[7]==1){
   							error_in_dc_dc=0;
   						}
   						else if(rx_can1_init.data[7]==0){
   							error_in_dc_dc=1;
   						}
   					 }
   	 			//	 FLEXCAN_DRV_Send(INST_CANCOM1,10U,&can1_data_init, 0x180E221,can_data_1);

   	 			break;
   	 		 }
   	 		case from_mcu : //MCU
   	 		{
   	 					mcu.on=1;

   	 					mcu.data[0]=rx_can1_init.data[0];
   	 			    	mcu.data[1]=rx_can1_init.data[1];
   	 					mcu.data[2]=rx_can1_init.data[2];
   	 					mcu.data[3]=rx_can1_init.data[3];
   	 					mcu.data[4]=rx_can1_init.data[4];
   	 					mcu.data[5]=rx_can1_init.data[5];
   	 					mcu.data[6]=rx_can1_init.data[6];
   	 					mcu.data[7]=rx_can1_init.data[7];

   	 					//	motor_rpm=motor_can[6]+motor_can[7]*256;
   	 					//motor_rpm=motor_rpm/8;
   	 					//canspeed=(2*3.14*0.825*motor_rpm)/60;
   	 					////canspeed=(3.14*0.630*motor_rpm)/(60*8);//(3.14*wheel dia *moter rpm / gear ratio(8))/60(sec))
   	 					///	canspeed=(3.14*0.630*motor_rpm)/(60*12);//12 is the gear ratio for tata ace
   	 					mcu.voltage=mcu.data[0]+mcu.data[1]*256;
   	 					mcu.voltage=mcu.voltage/10;
   	 					mcu.current=mcu.data[2]+mcu.data[3]*256;
   	 					mcu.current=mcu.current/10;
   	 					mcu.phase_current=mcu.data[4]+mcu.data[5]*256;
   	 					mcu.phase_current=mcu.phase_current/10;
						mcu.rpm=mcu.data[6]+mcu.data[7]*256;
						mcu.speed=(3.14*0.541*mcu.rpm)/(60*12);//12 is the gear ratio for tata ace
   	 				if(diagnosis_on==1){
   						if(mcu.voltage>=78){
   							mcu.error=0;
   						}
   						else if(mcu.voltage<78){
   							mcu.error=1;
   						}
   					 }
   	 		///       FLEXCAN_DRV_Send(INST_CANCOM1,11U,&can1_data_init, 0x180E421,can_data_1);///mail box id should be different to all the can data that are in diff CAN's
   	 				//  rx_can2_init.msgId=0;
   	 		   memset(rx_can1_init.data, 0, sizeof(rx_can1_init.data));

   	 		      break;
   	 		}

   	 		case from_imd : //IMD
   	 		{
   	 				imd_on=1;
   	 				if(diagnosis_on==1){
   						if(rx_can1_init.data[7]==1){
   							error_in_imd=0;
   						}
   						else if(rx_can1_init.data[7]==0){
   							error_in_imd=1;
   						}
   					 }
   	 			  memset(rx_can1_init.data, 0, sizeof(rx_can1_init.data));
   	 			 //    FLEXCAN_DRV_Send(INST_CANCOM1,12U,&can1_data_init, 0x180E921,can_data_1);///mail box id should be different to all the can data that are in diff CAN's

   	 			     //	  rx_can2_init.msgId=0;
   	 			 break;
   	 		}
   	 	case from_rfid : //rfid
   	 	   	 		{

   	 	   	 	rfid_tag=rx_can1_init.data[0];
   	 	    memset(rx_can1_init.data, 0, sizeof(rx_can1_init.data));
   	 	   	 			 break;
   	 	   	 		}


   	 	}
   	 	}

   	 }

   }

//
//if((rxHeader.ExtId==0x180128F1)  && (rxHeader.DLC==8) ){
//
//			//	c_motor++;
//			rxHeader.StdId=0x0;
//
//
//
//			//	if(motor_voltage>=80 && motor_current>=2 ){
//			motor_rpm=motor_can[6]+motor_can[7]*256;
//			canspeed=(3.14*0.541*motor_rpm)/(60*12);//12 is the gear ratio for tata ace
//			//	}
//
//			checking_for_motor_CAN_data=1;
//			memset(rxData, 0, sizeof(rxData));
//
//		}
//		else if (rxHeader.ExtId == 0x18F0E5F6  && (rxHeader.DLC==8))  {//data from bms
//			//	c_bms++;
//			rxHeader.StdId=0x0;
//			bms.data[0]=rxData[0];
//			bms_data[1]=rxData[1];
//			bms_data[2]=rxData[2];
//			bms_data[3]=rxData[3];
//			bms_data[4]=rxData[4];
//			bms_data[5]=rxData[5];
//			bms_data[6]=rxData[6];
//			bms_data[7]=rxData[7];
//			//  in_charg++;
//
//			voltage_bat=(bms_data[1]*256+bms_data[2]);
//			voltage_bat=voltage_bat/100;
//			current=(bms_data[3]*256+bms_data[4]);
//			current=(current-7000)/10;
//			socvalue=bms_data[6];
//			//				if(voltage_bat <89){
//			//					HAL_GPIO_WritePin(org_gnd_PORT, org_gnd, low);
//			//					HAL_GPIO_WritePin(org_pow_PORT, org_pow, high);
//			//				}
//			//	  flag_send_voltage_current=1;
//
//			if(bluetooth !='p' && nos_data != 'c'){
//				if(bms_data[0]==4)
//				{
//					bms_wake_up();
//				}
//				else if(bms_data[0]==2)
//				{
//					bms_discharge();
//				}
//
//				else if(bms_data[0]==5)
//				{
//					in_discharging=1;
//					in_charging=0;
//				}
//
//			}
//			else if( nos_data =='c'){
//				if(bms_data[0]==4)
//				{
//					bms_wake_up();
//
//				}
//				else if(bms_data[0]==2)
//				{
//					state=2;
//
//				}
//
//				else if(bms_data[0]==6)
//				{
//					in_charging=1;
//					if(charge_flag==1){
//						state=3;
//						charge_flag=0;
//					}
//
//
//				}
//			}
//
//
//		memset(rxData, 0, sizeof(rxData));
//
//		}
//
//
//		if ((rxHeader.StdId == 0x103)&&(rxHeader.DLC==8))//&&(rxHeader.DLC==8)
//		{
//			//	c_pi++;
//			rxHeader.ExtId=0x0;
//			// Successfully received a message
//			// Process the received data (rxData)
//			rx_buffer[0]=rxData[0];
//			rx_buffer[1]=rxData[1];
//			rx_buffer[2]=rxData[2];
//			rx_buffer[3]=rxData[3];
//			rx_buffer[4]=rxData[4];
//			rx_buffer[5]=rxData[5];
//			rx_buffer[6]=rxData[6];
//			rx_buffer[7]=rxData[7];
//
//			if(rx_buffer[0]>=65 && rx_buffer[0]<=90){
//				if(((rx_buffer[0]==70 )|| (rx_buffer[0]==82 )||(rx_buffer[0]==79 )|| (rx_buffer[0]==67))
//						&& ((rx_buffer[3]==70 )|| (rx_buffer[3]==82 )||(rx_buffer[3]==48 )))
//				{
//					nos_data_rx_ack=1;
//					//			can_msg_in++;
//
//					if((rx_buffer[0]!=data_rx[0])&&(rx_buffer[1]!=data_rx[1])&&(rx_buffer[2]!=data_rx[2])||(rx_buffer[3]!=data_rx[3])&&(rx_buffer[4]!=data_rx[4])&&(rx_buffer[5]!=data_rx[5])){//||(rx_buffer[6]!=data_rx[6])&&(rx_buffer[7]!=data_rx[7]) ){
//						bluetooth='0';
//						distance_stop_flag=1;
//						bt=0;
//						data_array_distance=3;
//						//if(rx==1){
//						data_array=0;
//						j=0;
//						in_nos=0;
//						stop_data=0;
//						current_dist=lidar_dist;
//						msg_recvd=1;
//						rev_count++;
//						///Setpoint=setpoint_value_max;
//
//						//					if(((rx_buffer[0]==70 )|| (rx_buffer[0]==82 )||(rx_buffer[0]==79 )|| (rx_buffer[0]==67))
//						//							&& ((rx_buffer[3]==70 )|| (rx_buffer[3]==82 )||(rx_buffer[3]==48 )))
//						//					{
//						//				  			while(j<8){
//						//				  				data_rx[j]=rxnum_data[j];
//						//				  				j++;
//						//				  			}
//						//				  			j=0;
//						///Setpoint=100;
//
//
//
//
//
//
//
//						forward_dis_start=0;
//						flag_rev=0;
//						flag_frv=0;
//						in_nos=0;
//
//						low_volt_flag=0;
//
//						data_rx[0]=rx_buffer[0];
//						data_rx[1]=rx_buffer[1];
//						data_rx[2]=rx_buffer[2];
//						data_rx[3]=rx_buffer[3];
//						data_rx[4]=rx_buffer[4];
//						data_rx[5]=rx_buffer[5];
//						data_rx[6]=rx_buffer[6];
//						data_rx[7]=rx_buffer[7];
//						//				  		if(initial_flag==0){
//						//				  			prv_loc[0]=data_rx[1];
//						//				  			initial_flag=1;
//						//				  		}
//
//						if(data_rx[data_array]=='F')
//
//						{
//							// nos=1;
//							//flag_send_uart=1;
//							//HAL_Delay(100);
//							//				  				HAL_UART_Transmit(&huart1, "$started#" , 9,100);
//							//				  				sprintf(started_send,"started");
//							////nos_data_rx_ack=1;
//							vehical_status=1;
//							in_nos=0;
//							rfid_tag=0;
//							distance_stop_flag=1;
//							nos_data=data_rx[data_array];
//
//							//						 start();
//							//						// HAL_Delay(10);
//							//						 nos=1;
//							//						 forward();
//
//
//						}
//						else  if(data_rx[data_array]=='R'){
//							//flag_send_uart=1;
//							//HAL_Delay(100);
//							//				  				rfid_tag=3;
//							//				  				HAL_UART_Transmit(&huart1, "$started#" , 9,100);
//							///nos_data_rx_ack=1;
//							vehical_status=1;
//							//sprintf(started_send,"started");
//							nos_data=data_rx[data_array];
//							distance_stop_flag=1;
//							in_nos=0;
//						}
//						else  if(data_rx[data_array]=='O'){
//							//flag_send_uart=1;
//							//HAL_Delay(100);
//							//				  				HAL_UART_Transmit(&huart1, "$oppened#" , 9,100);
//							//				  				sprintf(started_send,"oppened");
//							door_status=0;
//
//							nos_data=data_rx[data_array];
//
//						}
//						else  if(data_rx[data_array]=='C'){
//							//flag_send_uart=1;
//							//HAL_Delay(100);
//							//				  				HAL_UART_Transmit(&huart1, "$clossed#" , 9,100);
//							//				  				sprintf(started_send,"clossed");
//							door_status=1;
//							nos_data=data_rx[data_array];
//
//						}
//
//						//						if(rxnum_data[3]=='0' ||rxnum_data[3]=='F' ){
//						//							destination_distance=13;//1
//						//						}
//						//						else if(rxnum_data[3]=='R' ){
//						//							destination_distance=10;//7
//						//						}
//
//
//						data_array++;
//						if(prv_loc[0]==data_rx[data_array]){
//							loc[0]=data_rx[data_array];
//							data_array++;
//						}
//
//
//					}
//					//				else if((rx_buffer[0]==79 )){
//					//		              task_data[0]=rx_buffer[0];
//					//
//					//
//				}
//				else{
//
//					nos_data_rx_ack=1;
//
//				}
//
//
//
//
//			}
//			else if(rx_buffer[0]==1 && rx_buffer[1]==0 && rx_buffer[2]==8 && rx_buffer[6]==15 && rx_buffer[7]==170 ){
//				state=4;
//				//tim_flag=1;
//				//success=88;
//				stop_charge++;
//
//			}
//
//
//			else if(rx_buffer[0]==4 && rx_buffer[1]==5 && rx_buffer[2]==9 && rx_buffer[3]==0 && rx_buffer[4]==0 && rx_buffer[5]==0  && rx_buffer[6]==0 && rx_buffer[7]==170 ){
//				state=1;
//				nos_data='c';
//				sleep_bms=1;
//				in_charging=1;
//				in_discharging=0;
//				//			tx_flag=1;
//				//			success=55;
//
//				//	can_data_rx_feedback();
//			}
//
//			else if(rx_buffer[0]==1 && rx_buffer[1]==4 && rx_buffer[2]==3 && rx_buffer[3]==0 && rx_buffer[4]==0  && rx_buffer[5]==0 &&  rx_buffer[6]==0 && rx_buffer[7]==0 ){
//
//				head_lights_on();
//
//			}
//
//			//		if(prv_loc[0]==data_rx[2])
//			//		  {
//			//		nos_data='X';
//			//				}
//
//
//			messageReceived = 1;
//			memset(rxData, 0, sizeof(rxData));
//
//		}
//		else if ((rxHeader.ExtId == 0x186543f3) && (rxHeader.DLC==8)){//
//					//	 rxHeader.ExtId=0x0;
//					//	c_radar;
//					obj_detection=rxData[0];
//					memset(rxData, 0, sizeof(rxData));
//				}
//		else if ((rxHeader.StdId == 0x03) && (rxHeader.DLC==6)){//
//			//	c_lidar++;
//			rxHeader.ExtId=0x0;
//			lidar_can[0]=rxData[0];
//			lidar_can[1]=rxData[1];
//			lidar_can[2]=rxData[2];
//			lidar_can[3]=rxData[3];
//			lidar_can[4]=rxData[4];
//			lidar_can[5]=rxData[5];
//
//			lidar_dist=(lidar_can[0]+lidar_can[1]*256);
//			checking_for_LIDAR_data=1;
//			lidar_id=1;
//			memset(rxData, 0, sizeof(rxData));
//		}
//
//		else if ((rxHeader.StdId == 0x459) && (rxHeader.DLC==2)){
//			//c_comd;
//			rxHeader.ExtId=0x0;
//			Setpoint=rxData[1];
//			in_nos=0;
//			if(rxData[0]==1){
//				nos_data='F';
//			}
//			else if(rxData[0]==0){
//				nos_data='R';
//			}
//			//				txHeader.IDE = CAN_ID_STD; // Standard ID
//			//					txHeader.StdId = 0x555; // Standard identifier (11 bits)
//			//					//txHeader.ExtId = 0x00; // Extended identifier (not used in this case)
//			//					txHeader.RTR = CAN_RTR_DATA; // Data frame
//			//
//			//					txHeader.DLC = 2; // Data length code
//			//					//txHeader.TransmitGlobalTime = DISABLE; // Don't use the global time feature
//			//
//			//					brake_cnt[0]=0x00;
//			//					brake_cnt[1]=0x28;
//			//
//			//					HAL_CAN_AddTxMessage(&hcan, &txHeader, brake_cnt, &txMailbox);
//			memset(rxData, 0, sizeof(rxData));
//
//		}
//		else if ((rxHeader.ExtId == 0x1874530) && (rxHeader.DLC==8)){
//			//	c_brake++;
//			// rxHeader.xtId=0x0;
//			if((brake_Off==1)||(brake_On==1)){
//
//				byte4=rxData[4]<<8;
//				byte5=rxData[5];
//				applied_press=byte4|byte5;
//				applied_press=applied_press/10;
//				if(brake_On==1){
//					if(applied_press>=20 && applied_press<=30){
//						brake_On=0;
//					}
//				}
//				if(brake_Off==1){
//					if(  applied_press>=0 && applied_press<10){
//						brake_Off=0;
//					}
//				}
//			}
//
//
//			//	HAL_CAN_ActivateNotification(&hcan,CAN_IT_RX_FIFO0_FULL);
//			memset(rxData, 0, sizeof(rxData));
//		}
//		else if ((rxHeader.ExtId == 0x1A2B3C4D) && (rxHeader.DLC==8))
//		{
//			lidar_left=rxData[0]+rxData[1]*256;
//			memset(rxData, 0, sizeof(rxData));
//		}
//
//		else if ((rxHeader.ExtId == 0xABB1122) && (rxHeader.DLC==8))
//		{
//			lidar_right=rxData[0]+rxData[1]*256;
//			memset(rxData, 0, sizeof(rxData));
//		}
//
//
//	}

