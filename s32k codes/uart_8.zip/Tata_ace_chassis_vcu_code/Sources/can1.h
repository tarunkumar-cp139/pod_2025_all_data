/*
 * can1.h
 *
 *  Created on: 29-Oct-2025
 *      Author: Tarun
 */

#ifndef CAN1_H_
#define CAN1_H_

#include "main.h"
//#include "can0.h"


 extern flexcan_data_info_t can1_data_init,can1_data_init_std;
 extern flexcan_msgbuff_t rx_can1_init,rx_can1_init_std;

  void can1_config(void);
  void can1_callback (uint8_t instance, flexcan_event_type_t eventType,uint32_t buffIdx, flexcan_state_t flexcanState);
  extern uint16_t applied_press;
extern uint8_t can_data_1[8];
extern char rfid_tag;
typedef struct{
	bool rx_flag,on,error,ack;
	double rpm;
	double speed;
    float voltage,current,phase_current;
    uint8_t data[8],tx_data[8],check_sum,count;

}parameter;
extern parameter mcu,bms,brake,pdu,obc;
//extern CanChecks can1;
#endif /* CAN1_H_ */
