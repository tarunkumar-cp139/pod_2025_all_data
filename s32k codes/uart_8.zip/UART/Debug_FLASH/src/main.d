src/main.o: ../src/main.c \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h \
 ../src/clocks_and_modes.h ../src/LPUART.h

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h:

../src/clocks_and_modes.h:

../src/LPUART.h:
