SDK/platform/devices/S32K144/startup/system_S32K144.o: \
 ../SDK/platform/devices/S32K144/startup/system_S32K144.c \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h \
 ../SDK/platform/devices/S32K144/startup/system_S32K144.h

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h:

../SDK/platform/devices/S32K144/startup/system_S32K144.h:
