SDK/platform/drivers/src/lpuart/lpuart_irq.o: \
 ../SDK/platform/drivers/src/lpuart/lpuart_irq.c \
 ../SDK/platform/drivers/src/lpuart/lpuart_irq.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/interrupt_manager.h

../SDK/platform/drivers/src/lpuart/lpuart_irq.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/interrupt_manager.h:
