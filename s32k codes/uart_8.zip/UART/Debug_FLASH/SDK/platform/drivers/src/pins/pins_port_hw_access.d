SDK/platform/drivers/src/pins/pins_port_hw_access.o: \
 ../SDK/platform/drivers/src/pins/pins_port_hw_access.c \
 ../SDK/platform/drivers/src/pins/pins_port_hw_access.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/pins_driver.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/devices/status.h \
 ../SDK/platform/drivers/src/pins/pins_gpio_hw_access.h

../SDK/platform/drivers/src/pins/pins_port_hw_access.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/pins_driver.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/devices/status.h:

../SDK/platform/drivers/src/pins/pins_gpio_hw_access.h:
