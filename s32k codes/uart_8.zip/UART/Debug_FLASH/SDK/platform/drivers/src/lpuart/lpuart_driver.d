SDK/platform/drivers/src/lpuart/lpuart_driver.o: \
 ../SDK/platform/drivers/src/lpuart/lpuart_driver.c \
 ../SDK/platform/drivers/src/lpuart/lpuart_hw_access.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/lpuart_driver.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/devices/status.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/rtos/osif/osif.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/edma_driver.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/devices/callbacks.h \
 ../SDK/platform/drivers/src/lpuart/lpuart_irq.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/clock.h \
 c:\users\tarun\workspaces32ds.arm.2.2\uart\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

../SDK/platform/drivers/src/lpuart/lpuart_hw_access.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/lpuart_driver.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/devices/status.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/rtos/osif/osif.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/edma_driver.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/devices/callbacks.h:

../SDK/platform/drivers/src/lpuart/lpuart_irq.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/clock.h:

c:\users\tarun\workspaces32ds.arm.2.2\uart\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
