SDK/rtos/osif/osif_baremetal.o: ../SDK/rtos/osif/osif_baremetal.c \
 ../SDK/rtos/osif/osif.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/devices/status.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/interrupt_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/clock_manager.h \
 C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/clock.h \
 c:\users\tarun\workspaces32ds.arm.2.2\uart\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h

../SDK/rtos/osif/osif.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/devices/status.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/device_registers.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/s32_core_cm4.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/S32K144_features.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/include/devassert.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/interrupt_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/clock_manager.h:

C:/Users/Tarun/workspaceS32DS.ARM.2.2/UART/SDK/platform/drivers/inc/clock.h:

c:\users\tarun\workspaces32ds.arm.2.2\uart\sdk\platform\drivers\src\clock\s32k1xx\clock_s32k1xx.h:
